import React, { useState } from 'react';
import { Star, ThumbsUp, PlusCircle, CheckCircle, Sparkles, MessageSquare, ShieldCheck } from 'lucide-react';
import { RomReview, DeviceInfo } from '../types';

interface ReviewsSectionProps {
  reviews: RomReview[];
  devices: DeviceInfo[];
  onAddReview: (review: Omit<RomReview, 'id' | 'date' | 'upvotes' | 'verified'>) => void;
  onUpvoteReview: (id: string) => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({
  reviews,
  devices,
  onAddReview,
  onUpvoteReview
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [author, setAuthor] = useState('');
  const [telegramHandle, setTelegramHandle] = useState('');
  const [selectedDeviceCodename, setSelectedDeviceCodename] = useState('Ginkgo');
  const [romVersion, setRomVersion] = useState('ColorOS 15.0.2');
  const [rating, setRating] = useState(5);
  const [smoothnessRating, setSmoothnessRating] = useState(5);
  const [batteryLifeRating, setBatteryLifeRating] = useState(5);
  const [gamingRating, setGamingRating] = useState(4);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');

  const filteredReviews = selectedFilter === 'all'
    ? reviews
    : reviews.filter(r => r.deviceCodename.toLowerCase() === selectedFilter.toLowerCase());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !comment.trim() || !title.trim()) return;

    const matchedDevice = devices.find(d => d.codename.toLowerCase() === selectedDeviceCodename.toLowerCase());
    const deviceName = matchedDevice ? matchedDevice.name : selectedDeviceCodename;

    onAddReview({
      author: author.trim(),
      telegramHandle: telegramHandle.trim() ? (telegramHandle.startsWith('@') ? telegramHandle : `@${telegramHandle}`) : undefined,
      deviceName,
      deviceCodename: selectedDeviceCodename,
      romVersion,
      rating,
      title: title.trim(),
      comment: comment.trim(),
      smoothnessRating,
      batteryLifeRating,
      gamingRating
    });

    // Reset
    setAuthor('');
    setTelegramHandle('');
    setTitle('');
    setComment('');
    setIsModalOpen(false);
  };

  return (
    <section id="reviews" className="py-24 bg-[#0c0d10] text-white relative border-b border-[#1f2026]">
      
      {/* Background depth ambiance (solid dark, no gradients) */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-96 bg-[#161822] rounded-full blur-[140px] pointer-events-none -z-10 opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#131f17] border border-[#213829] text-emerald-400 text-xs font-bold font-mono">
              <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
              <span>REAL USER EXPERIENCES</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white font-display">
              Community Reviews
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 max-w-xl">
              Verified feedback from users who daily drive Aurora ColorOS on Redmi Note 8, Note 12 5G, and Note 7S.
            </p>
          </div>

          {/* Write a Review Button (Solid Red, no gradient) */}
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="self-start lg:self-auto px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md transition flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Write a Review</span>
          </button>
        </div>

        {/* Device Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-8">
          <span className="text-xs font-semibold text-neutral-400 mr-2">Filter Device:</span>
          <button
            type="button"
            onClick={() => setSelectedFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              selectedFilter === 'all'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'bg-[#15161c] text-neutral-400 hover:text-white border border-[#252630]'
            }`}
          >
            All ({reviews.length})
          </button>
          <button
            type="button"
            onClick={() => setSelectedFilter('ginkgo')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              selectedFilter === 'ginkgo'
                ? 'bg-blue-600 text-white font-bold shadow-sm'
                : 'bg-[#15161c] text-neutral-400 hover:text-white border border-[#252630]'
            }`}
          >
            Redmi Note 8/8T [Ginkgo]
          </button>
          <button
            type="button"
            onClick={() => setSelectedFilter('stone')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              selectedFilter === 'stone'
                ? 'bg-red-600 text-white font-bold shadow-sm'
                : 'bg-[#15161c] text-neutral-400 hover:text-white border border-[#252630]'
            }`}
          >
            Redmi Note 12 5G [Stone]
          </button>
          <button
            type="button"
            onClick={() => setSelectedFilter('lavender')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              selectedFilter === 'lavender'
                ? 'bg-emerald-600 text-white font-bold shadow-sm'
                : 'bg-[#15161c] text-neutral-400 hover:text-white border border-[#252630]'
            }`}
          >
            Redmi Note 7S [Lavender]
          </button>
        </div>

        {/* Reviews Cards List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredReviews.map((rev) => (
            <div
              key={rev.id}
              className="rounded-3xl bg-[#121318] border border-[#23242e] p-6 hover:border-[#353745] transition flex flex-col justify-between"
            >
              <div>
                {/* Header: Author & Device */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{rev.author}</span>
                      {rev.telegramHandle && (
                        <span className="text-[11px] text-blue-400 font-medium">{rev.telegramHandle}</span>
                      )}
                      {rev.verified && (
                        <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-emerald-400 bg-[#121c17] px-2 py-0.5 rounded-md border border-[#1f3529]">
                          <CheckCircle className="w-2.5 h-2.5" />
                          Verified
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-neutral-400 mt-0.5">
                      Flashing on {rev.deviceName} • {rev.romVersion}
                    </div>
                  </div>

                  {/* Stars */}
                  <div className="flex items-center gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${i < rev.rating ? 'text-amber-400 fill-amber-400' : 'text-neutral-700 fill-neutral-700'}`}
                      />
                    ))}
                  </div>
                </div>

                {/* Review Title */}
                <h4 className="font-bold text-white text-sm mb-1.5 font-display">
                  &ldquo;{rev.title}&rdquo;
                </h4>

                {/* Comment */}
                <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-4">
                  {rev.comment}
                </p>

                {/* Performance Pill Indicators */}
                <div className="flex flex-wrap gap-2 text-[10px] font-semibold text-neutral-400 mb-2">
                  <span className="px-2 py-0.5 rounded-md bg-[#181920] border border-[#272832]">
                    Smoothness: <span className="text-white font-bold">{rev.smoothnessRating}/5</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-[#181920] border border-[#272832]">
                    Battery: <span className="text-white font-bold">{rev.batteryLifeRating}/5</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-[#181920] border border-[#272832]">
                    Gaming: <span className="text-white font-bold">{rev.gamingRating}/5</span>
                  </span>
                </div>
              </div>

              {/* Card Footer: Date & Upvote */}
              <div className="pt-3 border-t border-[#1e1f28] flex items-center justify-between text-xs text-neutral-400">
                <span>{rev.date}</span>
                <button
                  type="button"
                  onClick={() => onUpvoteReview(rev.id)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#181920] hover:bg-blue-600 hover:text-white text-neutral-300 transition cursor-pointer border border-[#262732] active:scale-95"
                >
                  <ThumbsUp className="w-3 h-3" />
                  <span>Helpful ({rev.upvotes})</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Review Submission Modal (Solid styling) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-[#121318] border border-[#282935] rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
            <h3 className="text-2xl font-bold font-display text-white mb-1">
              Share Your ROM Experience
            </h3>
            <p className="text-xs text-neutral-400 mb-6">
              Your feedback helps fellow Redmi users choose the right build.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder="e.g. Alex"
                    className="w-full px-3 py-2 rounded-xl bg-[#181920] border border-[#292b36] text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Telegram Handle (optional)</label>
                  <input
                    type="text"
                    value={telegramHandle}
                    onChange={(e) => setTelegramHandle(e.target.value)}
                    placeholder="@username"
                    className="w-full px-3 py-2 rounded-xl bg-[#181920] border border-[#292b36] text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Your Device</label>
                  <select
                    value={selectedDeviceCodename}
                    onChange={(e) => setSelectedDeviceCodename(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#181920] border border-[#292b36] text-white text-xs focus:border-blue-500 focus:outline-none"
                  >
                    <option value="Ginkgo">Redmi Note 8/8T [Ginkgo]</option>
                    <option value="Stone">Redmi Note 12 5G [Stone]</option>
                    <option value="Lavender">Redmi Note 7S [Lavender]</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">ROM Version</label>
                  <input
                    type="text"
                    required
                    value={romVersion}
                    onChange={(e) => setRomVersion(e.target.value)}
                    placeholder="ColorOS 15.0.2 Stable"
                    className="w-full px-3 py-2 rounded-xl bg-[#181920] border border-[#292b36] text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Review Headline</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Buttery smooth 120fps with awesome battery!"
                  className="w-full px-3 py-2 rounded-xl bg-[#181920] border border-[#292b36] text-white text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Your Detailed Review</label>
                <textarea
                  required
                  rows={3}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Tell us about daily usability, camera, charging speed, and gaming performance..."
                  className="w-full px-3 py-2 rounded-xl bg-[#181920] border border-[#292b36] text-white text-xs focus:border-blue-500 focus:outline-none resize-none"
                />
              </div>

              {/* Star Rating Pickers */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">Overall</label>
                  <select
                    value={rating}
                    onChange={(e) => setRating(Number(e.target.value))}
                    className="w-full p-1.5 rounded-lg bg-[#181920] border border-[#292b36] text-xs text-white"
                  >
                    {[5, 4, 3, 2, 1].map((s) => (
                      <option key={s} value={s}>{s} Stars</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">Smoothness</label>
                  <select
                    value={smoothnessRating}
                    onChange={(e) => setSmoothnessRating(Number(e.target.value))}
                    className="w-full p-1.5 rounded-lg bg-[#181920] border border-[#292b36] text-xs text-white"
                  >
                    {[5, 4, 3, 2, 1].map((s) => (
                      <option key={s} value={s}>{s}/5</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">Battery</label>
                  <select
                    value={batteryLifeRating}
                    onChange={(e) => setBatteryLifeRating(Number(e.target.value))}
                    className="w-full p-1.5 rounded-lg bg-[#181920] border border-[#292b36] text-xs text-white"
                  >
                    {[5, 4, 3, 2, 1].map((s) => (
                      <option key={s} value={s}>{s}/5</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-neutral-400 mb-1">Gaming</label>
                  <select
                    value={gamingRating}
                    onChange={(e) => setGamingRating(Number(e.target.value))}
                    className="w-full p-1.5 rounded-lg bg-[#181920] border border-[#292b36] text-xs text-white"
                  >
                    {[5, 4, 3, 2, 1].map((s) => (
                      <option key={s} value={s}>{s}/5</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#181920] hover:bg-[#23242e] text-neutral-400 hover:text-white text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md cursor-pointer active:scale-95"
                >
                  Submit Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </section>
  );
};
