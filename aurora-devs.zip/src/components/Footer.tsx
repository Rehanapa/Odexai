import React from 'react';
import { Logo } from './Logo';
import { Send, Shield, MessageCircle } from 'lucide-react';
import { TELEGRAM_CHANNELS } from '../data/defaultData';

interface FooterProps {
  onOpenAdmin: () => void;
  telegramLink?: string;
  supportLink?: string;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenAdmin,
  telegramLink = TELEGRAM_CHANNELS.updates,
  supportLink = TELEGRAM_CHANNELS.support
}) => {
  return (
    <footer className="bg-[#0a0b0d] border-t border-[#1e1f28] pt-16 pb-12 text-neutral-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#1c1d25]">
          
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-4">
            <Logo size="lg" />
            <p className="text-xs sm:text-sm text-neutral-400 max-w-sm leading-relaxed">
              Custom ROM development portal delivering high-performance, buttery-smooth ColorOS ports for Redmi Note 8/8T, Note 12 5G, and Note 7S.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <a
                href={telegramLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-[#161720] text-blue-400 border border-[#262838] flex items-center justify-center hover:bg-blue-600 hover:text-white transition cursor-pointer"
                title="Updates Telegram"
              >
                <Send className="w-4 h-4" />
              </a>
              <a
                href={supportLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-[#161720] text-red-400 border border-[#262838] flex items-center justify-center hover:bg-red-600 hover:text-white transition cursor-pointer"
                title="Support Group"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <button
                type="button"
                onClick={onOpenAdmin}
                className="w-9 h-9 rounded-xl bg-[#161720] text-neutral-400 border border-[#262838] flex items-center justify-center hover:bg-white hover:text-black transition cursor-pointer"
                title="Admin Dashboard"
              >
                <Shield className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#overview" className="hover:text-white transition">Overview</a></li>
              <li><a href="#gallery" className="hover:text-white transition">Screenshots Gallery</a></li>
              <li><a href="#devices" className="hover:text-white transition">Supported Devices</a></li>
              <li><a href="#features" className="hover:text-white transition">Kernel & Features</a></li>
              <li><a href="#reviews" className="hover:text-white transition">Community Reviews</a></li>
              <li><a href="#community" className="hover:text-white transition">Development Team</a></li>
            </ul>
          </div>

          {/* Supported Devices */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Devices
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#devices" className="hover:text-white transition flex items-center gap-1">
                  <span>Redmi Note 8/8T</span>
                  <span className="text-[10px] text-neutral-500">[Ginkgo]</span>
                </a>
              </li>
              <li>
                <a href="#devices" className="hover:text-white transition flex items-center gap-1">
                  <span>Redmi Note 12 5G</span>
                  <span className="text-[10px] text-neutral-500">[Stone]</span>
                </a>
              </li>
              <li>
                <a href="#devices" className="hover:text-white transition flex items-center gap-1">
                  <span>Redmi Note 7S</span>
                  <span className="text-[10px] text-neutral-500">[Lavender]</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Team Credits Box (User Request) */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              AURORA Credits
            </h4>
            <div className="text-xs space-y-2 p-4 rounded-2xl bg-[#121318] border border-[#22242f]">
              <div>
                <span className="text-neutral-500">Owner & Lead Dev:</span>{' '}
                <a href="https://t.me/isaec_newton" target="_blank" rel="noopener noreferrer" className="font-bold text-white hover:text-blue-400 hover:underline">
                  @isaec_newton
                </a>
              </div>
              <div>
                <span className="text-neutral-500">Moderator:</span>{' '}
                <a href="https://t.me/im_nagasaki" target="_blank" rel="noopener noreferrer" className="font-bold text-white hover:text-blue-400 hover:underline">
                  @im_nagasaki
                </a>{' '}
                <span className="text-[10px] text-neutral-500">(Mr Kurohane)</span>
              </div>
              <div>
                <span className="text-neutral-500">Website Design:</span>{' '}
                <span className="font-bold text-neutral-300">Abdur Rahman (@MATRIX)</span>
              </div>
            </div>
          </div>

        </div>

        {/* Legal Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            &copy; {new Date().getFullYear()} AURORA DEVs. Built with pride for the custom Android community.
          </div>
          <div className="text-center sm:text-right max-w-md">
            Custom firmware is not affiliated with Xiaomi Inc. or OPPO Telecommunications. Flash at your own discretion.
          </div>
        </div>

      </div>
    </footer>
  );
};
