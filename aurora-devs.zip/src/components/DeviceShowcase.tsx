import React, { useState } from 'react';
import { Download, Send, FileText, CheckCircle2, Cpu, Battery, Sparkles, BookOpen, Search, X } from 'lucide-react';
import { RomRelease, DeviceInfo } from '../types';

interface DeviceShowcaseProps {
  roms: RomRelease[];
  devices: DeviceInfo[];
  onOpenChangelog: (rom: RomRelease) => void;
  onOpenFlashingGuide: (device: DeviceInfo) => void;
}

export const DeviceShowcase: React.FC<DeviceShowcaseProps> = ({
  roms,
  devices,
  onOpenChangelog,
  onOpenFlashingGuide
}) => {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredRoms = roms.filter((r) => {
    const matchesTab = activeTab === 'all' || r.codename.toLowerCase() === activeTab.toLowerCase();
    const query = searchQuery.trim().toLowerCase();
    if (!query) return matchesTab;
    const matchesQuery =
      r.name.toLowerCase().includes(query) ||
      r.deviceModel.toLowerCase().includes(query) ||
      r.codename.toLowerCase().includes(query) ||
      r.chipset.toLowerCase().includes(query) ||
      r.colorOsVersion.toLowerCase().includes(query);
    return matchesTab && matchesQuery;
  });

  // Visual device Mockup using user's real hardware render assets & real screenshots
  const renderDeviceVisual = (codename: string) => {
    switch (codename.toLowerCase()) {
      case 'ginkgo':
        return (
          <div className="relative w-full h-56 flex items-center justify-center p-3 select-none bg-[#0c0d10] rounded-2xl border border-[#22232b]">
            {/* Cutout Phone Asset 1 */}
            <img
              src="/screenshots/1000005215-removebg-preview.png"
              alt="Redmi Note 8 hardware render"
              className="h-48 w-auto object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-300"
            />
          </div>
        );

      case 'stone':
        return (
          <div className="relative w-full h-56 flex items-center justify-center p-3 select-none bg-[#0c0d10] rounded-2xl border border-[#22232b]">
            {/* Cutout Phone Asset 2 */}
            <img
              src="/screenshots/1000005216-removebg-preview.png"
              alt="Redmi Note 12 5G hardware render"
              className="h-44 w-auto object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-300"
            />
          </div>
        );

      case 'lavender':
      default:
        return (
          <div className="relative w-full h-56 flex items-center justify-center p-3 select-none bg-[#0c0d10] rounded-2xl border border-[#22232b]">
            <img
              src="/section-04_slider_3.png"
              alt="Redmi Note 7S hardware render"
              className="h-44 w-auto object-contain drop-shadow-2xl hover:scale-105 transition-transform duration-300"
            />
          </div>
        );
    }
  };

  return (
    <section id="devices" className="py-24 bg-[#0c0d10] text-white relative border-b border-[#1f2026]">
      
      {/* Background depth ambiance (solid dark colors, no gradients) */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#161822] rounded-full blur-[140px] pointer-events-none -z-10 opacity-50" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-[#181216] rounded-full blur-[140px] pointer-events-none -z-10 opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading matching User's Slide 3 */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#1f1b20] border border-[#38262c] text-red-500 text-xs font-bold font-mono">
              <Sparkles className="w-3.5 h-3.5 text-red-500" />
              <span>OFFICIAL PORT MATRIX</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white font-display uppercase">
              SUPPORTED DEVICES
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 max-w-xl">
              Each ROM is tailored with custom vendor trees, optimized kernel schedulers, and zero telemetry for maximum speed and longevity.
            </p>
          </div>
        </div>

        {/* Controls Row: Search Input + Device Filter Tabs */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-10">
          {/* Search Bar to filter ROM releases by device name or codename */}
          <div className="relative w-full lg:max-w-md">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="device-rom-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by device name or codename (e.g. Note 8, Stone, Lavender)..."
              className="w-full pl-10 pr-9 py-2.5 rounded-2xl bg-[#14151b] border border-[#272834] text-white text-xs placeholder:text-neutral-500 focus:outline-none focus:border-blue-500 transition shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white transition p-1 cursor-pointer"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Tabs (Solid pill styling) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-2xl bg-[#16171d] border border-[#272832] text-xs font-semibold text-neutral-400 self-start lg:self-auto">
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-white text-black font-bold shadow-md'
                  : 'hover:text-white hover:bg-[#202129]'
              }`}
            >
              All Devices ({roms.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ginkgo')}
              className={`px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
                activeTab === 'ginkgo'
                  ? 'bg-blue-600 text-white font-bold shadow-md'
                  : 'hover:text-white hover:bg-[#202129]'
              }`}
            >
              Note 8/8T [Ginkgo]
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('stone')}
              className={`px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
                activeTab === 'stone'
                  ? 'bg-red-600 text-white font-bold shadow-md'
                  : 'hover:text-white hover:bg-[#202129]'
              }`}
            >
              Note 12 5G [Stone]
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('lavender')}
              className={`px-3.5 py-1.5 rounded-xl transition cursor-pointer ${
                activeTab === 'lavender'
                  ? 'bg-emerald-600 text-white font-bold shadow-md'
                  : 'hover:text-white hover:bg-[#202129]'
              }`}
            >
              Note 7S [Lavender]
            </button>
          </div>
        </div>

        {/* Empty State when search returns no matching ROMs */}
        {filteredRoms.length === 0 ? (
          <div className="rounded-3xl bg-[#121318] border border-[#242530] p-12 text-center my-6">
            <div className="w-12 h-12 rounded-2xl bg-[#1d1e26] flex items-center justify-center mx-auto mb-4 text-neutral-400">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-1">No ROM releases found</h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto mb-4">
              No supported device matches &ldquo;{searchQuery}&rdquo;. Try searching for another model or codename like &ldquo;Note 8&rdquo;, &ldquo;Stone&rdquo;, or &ldquo;Lavender&rdquo;.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setActiveTab('all');
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition cursor-pointer"
            >
              Clear search filter
            </button>
          </div>
        ) : (
          /* Device Cards Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRoms.map((rom) => {
              const deviceMeta = devices.find(d => d.codename.toLowerCase() === rom.codename.toLowerCase());

              return (
                <div
                  key={rom.id}
                  className="group relative rounded-3xl bg-[#121318] border border-[#242530] p-6 hover:border-[#383a48] transition-all duration-300 flex flex-col justify-between"
                >
                  {/* Top Badge & Status */}
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="px-3 py-1 rounded-md text-xs font-bold tracking-wide uppercase bg-[#1a1b24] text-blue-400 border border-[#2b2d3c]">
                        [{rom.codename}]
                      </span>
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-[#121c17] px-2.5 py-0.5 rounded-md border border-[#1f3529]">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        {rom.status}
                      </span>
                    </div>

                    {/* Device Title */}
                    <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
                      {rom.deviceModel}
                    </h3>
                    <div className="text-xs text-neutral-400 mt-0.5">
                      {rom.colorOsVersion} • Maintainer: <span className="text-white font-semibold">{rom.maintainer}</span>
                    </div>

                    {/* 3D Visual Device Render */}
                    <div className="my-4 overflow-hidden group-hover:scale-[1.01] transition-transform duration-300">
                      {renderDeviceVisual(rom.codename)}
                    </div>

                    {/* Description from user request */}
                    <p className="text-xs text-neutral-400 leading-relaxed min-h-[44px]">
                      {rom.description}
                    </p>

                    {/* Quick Specs Grid */}
                    <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] p-2.5 rounded-xl bg-[#16171e] border border-[#252632]">
                      <div className="flex items-center gap-1.5 text-neutral-300">
                        <Cpu className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                        <span className="truncate font-medium">{rom.chipset.split('(')[0]}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-neutral-300">
                        <Battery className="w-3.5 h-3.5 text-red-500 shrink-0" />
                        <span className="truncate font-medium">Size: {rom.fileSize}</span>
                      </div>
                    </div>
                  </div>

                  {/* Card Action Buttons (Solid colors, no gradients) */}
                  <div className="mt-6 pt-4 border-t border-[#1f202a] space-y-2">
                    {/* Direct Telegram Download Button (Requested) */}
                    <a
                      href={rom.downloadTelegramUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download on Telegram</span>
                      <Send className="w-3.5 h-3.5 opacity-80" />
                    </a>

                    {/* Secondary Modals: Changelog & Flashing Guide */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => onOpenChangelog(rom)}
                        className="py-2.5 px-3 rounded-xl bg-[#181920] hover:bg-[#242530] text-neutral-300 hover:text-white font-semibold text-xs border border-[#2a2b36] transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5 text-neutral-400" />
                        <span>Changelog</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => deviceMeta && onOpenFlashingGuide(deviceMeta)}
                        className="py-2.5 px-3 rounded-xl bg-[#181920] hover:bg-[#242530] text-neutral-300 hover:text-white font-semibold text-xs border border-[#2a2b36] transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <BookOpen className="w-3.5 h-3.5 text-blue-400" />
                        <span>Flash Guide</span>
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
