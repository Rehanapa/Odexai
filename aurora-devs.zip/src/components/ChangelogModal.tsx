import React from 'react';
import { RomRelease } from '../types';
import { FileText, Download, Send, CheckCircle2 } from 'lucide-react';

interface ChangelogModalProps {
  rom: RomRelease | null;
  onClose: () => void;
}

export const ChangelogModal: React.FC<ChangelogModalProps> = ({ rom, onClose }) => {
  if (!rom) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-3xl bg-[#121318] p-6 sm:p-8 shadow-2xl border border-[#252736] text-white max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-[#21232e] mb-6">
          <div>
            <span className="text-xs font-bold text-blue-400 uppercase tracking-wider font-mono">
              {rom.status} Build
            </span>
            <h3 className="text-2xl font-bold text-white font-display mt-0.5">
              {rom.name}
            </h3>
            <p className="text-xs text-neutral-400">{rom.deviceModel} [{rom.codename}]</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-[#1d1f2b] text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Build Specs Grid */}
        <div className="grid grid-cols-3 gap-2 text-xs mb-6 p-3 rounded-2xl bg-[#171822] border border-[#262838] text-center">
          <div>
            <div className="text-[10px] text-neutral-400">Release Date</div>
            <div className="font-bold text-white mt-0.5">{rom.releaseDate}</div>
          </div>
          <div>
            <div className="text-[10px] text-neutral-400">File Size</div>
            <div className="font-bold text-white mt-0.5">{rom.fileSize}</div>
          </div>
          <div>
            <div className="text-[10px] text-neutral-400">Maintainer</div>
            <div className="font-bold text-blue-400 mt-0.5">{rom.maintainer}</div>
          </div>
        </div>

        {/* Changelog Items */}
        <div className="space-y-3 mb-6">
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5 font-mono">
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>Changelog Highlights</span>
          </h4>

          <div className="space-y-2 text-xs text-neutral-300">
            {rom.changelog.map((log, index) => (
              <div key={index} className="flex items-start gap-2.5 p-2 rounded-xl hover:bg-[#181924] transition">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{log}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-4 border-t border-[#21232e] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-neutral-400 hover:text-white hover:bg-[#1d1f2b] cursor-pointer"
          >
            Close
          </button>

          <a
            href={rom.downloadTelegramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download on Telegram</span>
            <Send className="w-3 h-3" />
          </a>
        </div>

      </div>
    </div>
  );
};
