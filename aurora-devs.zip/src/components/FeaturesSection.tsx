import React from 'react';
import { 
  Zap, 
  Layers, 
  BatteryCharging, 
  Volume2, 
  ShieldCheck, 
  Sliders, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: Zap,
      title: 'Smoothhh Like Butter 120Hz',
      description: 'Zero frame stuttering. Custom CPU frequency governor locks peak animation performance during window transitions and gesture navigation.',
      badge: 'Fluid Engine',
      accentBg: 'bg-blue-600',
      badgeColor: 'bg-[#151d2e] text-blue-400 border border-[#233554]'
    },
    {
      icon: Layers,
      title: 'Frosted Glass & Liquid Physics',
      description: 'True real-time GPU-accelerated backdrop blur shaders. No static pre-rendered masks — authentic ColorOS 15 aquamorphic design.',
      badge: 'Visual Design',
      accentBg: 'bg-emerald-600',
      badgeColor: 'bg-[#14231b] text-emerald-400 border border-[#214330]'
    },
    {
      icon: BatteryCharging,
      title: 'Deep-Sleep Battery Architecture',
      description: 'Overnight idle standby drain drops to under 0.4% per hour. Intelligent background wakelock freezer protects your battery health.',
      badge: 'Endurance',
      accentBg: 'bg-red-600',
      badgeColor: 'bg-[#251518] text-red-400 border border-[#44232a]'
    },
    {
      icon: Volume2,
      title: 'Dolby Atmos & Studio Audio',
      description: 'Lossless Hi-Res audio DSP integration with custom equalizers for headphones, Bluetooth LDAC codecs, and stereo speaker enhancement.',
      badge: 'Acoustics',
      accentBg: 'bg-[#3E2D27]',
      badgeColor: 'bg-[#211b17] text-[#c99a7e] border border-[#3b2f28]'
    },
    {
      icon: ShieldCheck,
      title: 'Play Integrity & Banking Ready',
      description: 'MEETS_STRONG_INTEGRITY passes out-of-the-box. Google Pay, bKash, Revolut, and enterprise work profiles function without Magisk hiding tricks.',
      badge: 'Security',
      accentBg: 'bg-blue-600',
      badgeColor: 'bg-[#151d2e] text-blue-400 border border-[#233554]'
    },
    {
      icon: Sliders,
      title: 'Art+ Project & Flux Themes',
      description: 'Exclusive lockscreen depth wallpapers, custom Always-On Display animated clocks, and dynamic theme accents in red and blue.',
      badge: 'Customization',
      accentBg: 'bg-red-600',
      badgeColor: 'bg-[#251518] text-red-400 border border-[#44232a]'
    }
  ];

  return (
    <section id="features" className="py-24 bg-[#0a0b0d] text-white relative border-b border-[#1f2026]">
      
      {/* Background depth ambiance (solid dark, no gradients) */}
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-[#161822] rounded-full blur-[140px] pointer-events-none -z-10 opacity-40" />
      <div className="absolute bottom-10 left-0 w-96 h-96 bg-[#181216] rounded-full blur-[140px] pointer-events-none -z-10 opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#161720] border border-[#252736] text-blue-400 text-xs font-bold font-mono">
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>UNDER THE HOOD ENGINEERING</span>
          </div>
          
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white font-display">
            Built For Pure Speed & Elegance
          </h2>
          
          <p className="text-sm sm:text-base text-neutral-400">
            Engineered by enthusiasts, for enthusiasts. We stripped away bloatware and tuned kernel parameters to deliver an unmatched flagship experience.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                className="group relative rounded-3xl bg-[#111216] border border-[#20222a] p-7 hover:border-[#353745] transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className={`w-12 h-12 rounded-2xl ${feat.accentBg} flex items-center justify-center text-white group-hover:scale-105 transition-transform shadow-md`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md ${feat.badgeColor}`}>
                      {feat.badge}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white font-display mb-2">
                    {feat.title}
                  </h3>
                  
                  <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
                    {feat.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#1a1c24] flex items-center text-xs font-semibold text-blue-400 group-hover:text-blue-300">
                  <span>Tested on Ginkgo, Stone & Lavender</span>
                  <ArrowRight className="w-3 h-3 ml-1.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
