import React, { useState, useEffect } from 'react';
import { Download, Send, ArrowRight, Eye, ShieldCheck, Zap, Sparkles } from 'lucide-react';
import { TELEGRAM_CHANNELS } from '../data/defaultData';
import { PhoneHardwareFrame } from './PhoneHardwareFrame';
import { ScreenshotGalleryItem } from '../types';

interface HeroProps {
  onScrollToDevices: () => void;
  onScrollToGallery: () => void;
  onOpenScreenshot?: (screenId: string) => void;
  telegramLink?: string;
}

export const Hero: React.FC<HeroProps> = ({
  onScrollToDevices,
  onScrollToGallery,
  onOpenScreenshot,
  telegramLink = TELEGRAM_CHANNELS.updates,
}) => {
  // Parallax mouse tilt effect
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 20; // -10 to +10 deg
      const y = (e.clientY / innerHeight - 0.5) * -20;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section
      id="overview"
      className="relative min-h-[92vh] bg-[#0c0d10] text-white pt-24 pb-20 overflow-hidden flex items-center border-b border-[#1f2026]"
    >
      {/* Subtle misty ambient atmosphere on bottom-left (matching the reference slide, no gradients) */}
      <div className="absolute -bottom-20 -left-20 w-[550px] h-[550px] bg-[#1a1c24] rounded-full blur-[140px] pointer-events-none opacity-40 -z-10" />
      <div className="absolute top-10 right-0 w-[450px] h-[450px] bg-[#14151c] rounded-full blur-[120px] pointer-events-none opacity-30 -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Direct reproduction of the reference presentation typography & text */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left z-20">
            
            {/* Top Brand Marker (From Slide) */}
            <div className="flex items-center justify-center lg:justify-start gap-3">
              <span className="text-sm sm:text-base font-bold tracking-[0.22em] text-white uppercase font-display">
                AURORA DEVs
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-[#1c1e26] text-blue-400 border border-[#2c2e3a]">
                ColorOS 15 Port
              </span>
            </div>

            {/* Giant Headline: Smoothhh Like A Butter */}
            <div className="space-y-1">
              <h1 className="flex flex-col">
                <span className="font-serif-italic text-5xl sm:text-7xl xl:text-8xl text-white font-normal leading-[1.02] tracking-tight">
                  Smoothhh Like A
                </span>
                <span className="font-display font-extrabold text-5xl sm:text-7xl xl:text-8xl text-white tracking-tight uppercase leading-[0.98] mt-1">
                  Butter
                </span>
              </h1>
            </div>

            {/* Editorial Description */}
            <p className="text-neutral-300 text-sm sm:text-base max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Official custom port engineered for seamless 60/120 FPS performance,
              tactile frosted quick settings, and uncompromised battery longevity on
              Redmi Note 8/8T, Note 12 5G, and Note 7S.
            </p>

            {/* Presented by @isaec_newton (From User Slide) */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 text-xs">
              <div className="px-3 py-1.5 rounded-lg bg-[#181920] border border-[#2b2c36] text-neutral-300 flex items-center gap-1.5">
                <span className="text-neutral-400">Presented by</span>
                <a
                  href="https://t.me/isaec_newton"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white font-bold hover:underline hover:text-blue-400 transition-colors"
                >
                  @isaec_newton
                </a>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-[#181920] border border-[#2b2c36] text-neutral-300 flex items-center gap-1.5">
                <span className="text-neutral-400">Designed by</span>
                <span className="text-white font-bold">Abdur Rahman</span>
              </div>
            </div>

            {/* Solid Action Buttons (NO GRADIENTS) */}
            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-3.5">
              <button
                type="button"
                onClick={onScrollToDevices}
                className="px-6 py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-xl flex items-center gap-2 cursor-pointer active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>Download ROMs</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              <a
                href={telegramLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-xl flex items-center gap-2 cursor-pointer active:scale-95 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>Join Updates Telegram</span>
              </a>

              <button
                type="button"
                onClick={onScrollToGallery}
                className="px-5 py-3.5 rounded-xl bg-[#1a1b22] hover:bg-[#262730] border border-[#30323e] text-neutral-200 hover:text-white font-semibold text-sm flex items-center gap-2 cursor-pointer transition-all"
              >
                <Eye className="w-4 h-4 text-neutral-400" />
                <span>View Screenshots</span>
              </button>
            </div>

            {/* Quick Solid Spec Badges */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-lg mx-auto lg:mx-0">
              <div className="p-2.5 rounded-xl bg-[#14151b] border border-[#242630] text-left">
                <div className="text-blue-500 font-bold text-base font-display">60 / 120</div>
                <div className="text-[10px] text-neutral-400">Locked FPS</div>
              </div>
              <div className="p-2.5 rounded-xl bg-[#14151b] border border-[#242630] text-left">
                <div className="text-red-500 font-bold text-base font-display">0.4% / hr</div>
                <div className="text-[10px] text-neutral-400">Standby Drain</div>
              </div>
              <div className="p-2.5 rounded-xl bg-[#14151b] border border-[#242630] text-left">
                <div className="text-white font-bold text-base font-display">Zero</div>
                <div className="text-[10px] text-neutral-400">Bloatware</div>
              </div>
              <div className="p-2.5 rounded-xl bg-[#14151b] border border-[#242630] text-left">
                <div className="text-green-500 font-bold text-base font-display">100%</div>
                <div className="text-[10px] text-neutral-400">Passes Banking</div>
              </div>
            </div>

          </div>

          {/* Right Column: 4 Angled Floating Phones (Matching Image 1 Exact Layout) */}
          <div className="lg:col-span-6 relative flex items-center justify-center min-h-[520px] sm:min-h-[600px] perspective-1000">
            
            {/* Multi-phone 3D Stage with Interactive Parallax */}
            <div
              className="relative w-full max-w-[560px] h-[520px] sm:h-[600px] preserve-3d transition-transform duration-300 ease-out"
              style={{
                transform: `rotateY(${mousePos.x * 0.4}deg) rotateX(${mousePos.y * 0.4}deg)`,
              }}
            >
              
              {/* Phone 1: Top Left - Home Screen */}
              <div
                className="absolute top-2 left-2 sm:left-6 w-[170px] sm:w-[210px] z-20 cursor-pointer transition-transform duration-300 hover:scale-105 hover:z-40"
                style={{
                  transform: `translateZ(40px) rotate(-6deg)`,
                }}
                onClick={() => onOpenScreenshot && onOpenScreenshot('screen-home')}
                title="Click to expand Home Screen"
              >
                <PhoneHardwareFrame
                  src="/screenshots/Screenshot_2026-08-29-14-11-49-10_b783bf344239542886fee7b48fa4b892.jpg"
                  alt="ColorOS 15 Fluid Home Screen"
                  badge="Home Screen"
                  badgeColor="green"
                />
              </div>

              {/* Phone 2: Top Right - Frosted Control Center */}
              <div
                className="absolute top-0 right-0 sm:right-4 w-[170px] sm:w-[210px] z-10 cursor-pointer transition-transform duration-300 hover:scale-105 hover:z-40"
                style={{
                  transform: `translateZ(20px) rotate(8deg)`,
                }}
                onClick={() => onOpenScreenshot && onOpenScreenshot('screen-control')}
                title="Click to expand Control Center"
              >
                <PhoneHardwareFrame
                  src="/screenshots/Screenshot_2026-09-05-00-18-09-73_b783bf344239542886fee7b48fa4b892.jpg"
                  alt="ColorOS 15 Frosted Control Center"
                  badge="Control Center"
                  badgeColor="blue"
                />
              </div>

              {/* Phone 3: Bottom Left / Center - App Drawer */}
              <div
                className="absolute bottom-2 left-8 sm:left-14 w-[165px] sm:w-[200px] z-30 cursor-pointer transition-transform duration-300 hover:scale-105 hover:z-40"
                style={{
                  transform: `translateZ(60px) rotate(-3deg)`,
                }}
                onClick={() => onOpenScreenshot && onOpenScreenshot('screen-drawer')}
                title="Click to expand App Drawer"
              >
                <PhoneHardwareFrame
                  src="/screenshots/Screenshot_2026-09-04-22-50-36-43_b783bf344239542886fee7b48fa4b892.jpg"
                  alt="ColorOS 15 Fast App Drawer"
                  badge="App Drawer"
                  badgeColor="brown"
                />
              </div>

              {/* Phone 4: Bottom Right - Lock Screen Depth Clock */}
              <div
                className="absolute bottom-6 right-2 sm:right-8 w-[175px] sm:w-[215px] z-25 cursor-pointer transition-transform duration-300 hover:scale-105 hover:z-40"
                style={{
                  transform: `translateZ(50px) rotate(5deg)`,
                }}
                onClick={() => onOpenScreenshot && onOpenScreenshot('screen-lock')}
                title="Click to expand Lock Screen"
              >
                <PhoneHardwareFrame
                  src="/screenshots/Screenshot_2026-08-29-14-11-17-52.jpg"
                  alt="ColorOS 15 Lock Screen Depth Clock"
                  badge="Depth Clock"
                  badgeColor="red"
                />
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
