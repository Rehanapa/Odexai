import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  withText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ 
  className = '', 
  size = 'md',
  withText = true 
}) => {
  const sizeMap = {
    sm: { box: 'w-8 h-8', text: 'text-base', sub: 'text-[9px]' },
    md: { box: 'w-10 h-10', text: 'text-lg', sub: 'text-[10px]' },
    lg: { box: 'w-14 h-14', text: 'text-2xl', sub: 'text-xs' },
    xl: { box: 'w-20 h-20', text: 'text-3xl', sub: 'text-sm' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Aurora Circular Logo Badge */}
      <div className={`relative ${currentSize.box} rounded-full p-[2px] bg-gradient-to-tr from-rose-500 via-red-500 to-blue-600 shadow-md shadow-red-500/20 flex-shrink-0 group`}>
        <div className="absolute -inset-0.5 bg-gradient-to-r from-red-500 to-blue-500 rounded-full blur-[3px] opacity-70 group-hover:opacity-100 transition duration-500 animate-pulse"></div>
        <div className="relative w-full h-full rounded-full bg-gradient-to-br from-red-600 via-rose-500 to-orange-500 flex flex-col items-center justify-center text-white overflow-hidden shadow-inner">
          {/* Subtle Aurora light beam inside */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-blue-400/20 mix-blend-overlay"></div>
          
          <span className="font-extrabold tracking-tighter text-[11px] leading-none uppercase drop-shadow-sm">
            Aurora
          </span>
          <span className="font-bold tracking-widest text-[6px] opacity-90 uppercase border-t border-white/40 pt-[1px] mt-[1px]">
            DEVS
          </span>
        </div>
      </div>

      {withText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-brand font-extrabold tracking-tight text-slate-900 ${currentSize.text}`}>
              AURORA
            </span>
            <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 border border-blue-200/60">
              DEVS
            </span>
          </div>
          <span className={`font-medium tracking-wide text-slate-400 uppercase ${currentSize.sub}`}>
            ColorOS Port Portal
          </span>
        </div>
      )}
    </div>
  );
};
