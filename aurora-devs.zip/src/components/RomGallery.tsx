import React, { useState, useRef, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Play,
  Pause,
  Grid,
  SlidersHorizontal,
  Smartphone,
  CheckCircle2
} from 'lucide-react';
import { COLOROS_SCREENSHOTS } from '../data/defaultData';
import { ScreenshotGalleryItem } from '../types';
import { PhoneHardwareFrame } from './PhoneHardwareFrame';

interface RomGalleryProps {
  onSelectScreenshot: (item: ScreenshotGalleryItem) => void;
  screenshots?: ScreenshotGalleryItem[];
}

export const RomGallery: React.FC<RomGalleryProps> = ({ 
  onSelectScreenshot,
  screenshots = COLOROS_SCREENSHOTS 
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'horizon' | 'grid'>('horizon');
  const [isAutoScrolling, setIsAutoScrolling] = useState<boolean>(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const categories = ['All', 'System UI', 'Control Center', 'Lock Screen', 'Settings', 'Personalization'];

  const allScreenshots = screenshots && screenshots.length > 0 ? screenshots : COLOROS_SCREENSHOTS;

  const filteredScreens = selectedCategory === 'All'
    ? allScreenshots
    : allScreenshots.filter((s) => s.category === selectedCategory);

  // Smooth scroll left / right
  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -380 : 380;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  // Auto-scroll loop effect
  useEffect(() => {
    if (!isAutoScrolling || viewMode !== 'horizon') return;

    const interval = setInterval(() => {
      if (scrollContainerRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
        if (scrollLeft + clientWidth >= scrollWidth - 10) {
          scrollContainerRef.current.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          scrollContainerRef.current.scrollBy({ left: 2, behavior: 'auto' });
        }
      }
    }, 30);

    return () => clearInterval(interval);
  }, [isAutoScrolling, viewMode]);

  return (
    <section id="gallery" className="py-24 bg-[#0e0f13] text-white relative overflow-hidden border-b border-[#1f2026]">
      
      {/* Ambient soft backlight (solid colors, no gradients) */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-3/4 h-96 bg-[#161822] rounded-full blur-[160px] pointer-events-none -z-10 opacity-60" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
              <span className="text-xs font-bold tracking-widest text-blue-400 uppercase font-mono">
                REAL DEVICE SCREENSHOTS
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-white">
              ColorOS 15 Gallery
            </h2>
            <p className="text-neutral-400 text-sm sm:text-base max-w-xl mt-2">
              Captured directly from running Redmi Note 8 and Note 12 builds. Explore the
              depth-isolated lockscreens, frosted blur quick controls, and buttery 60 FPS transitions.
            </p>
          </div>

          {/* Controls: Horizon/Grid Switcher + Auto Scroll Toggle */}
          <div className="flex items-center gap-3">
            {viewMode === 'horizon' && (
              <button
                type="button"
                onClick={() => setIsAutoScrolling(!isAutoScrolling)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-colors cursor-pointer ${
                  isAutoScrolling
                    ? 'bg-blue-600 text-white border-blue-500'
                    : 'bg-[#181920] text-neutral-300 border-[#2a2b34] hover:bg-[#22232c]'
                }`}
              >
                {isAutoScrolling ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>Auto Flow</span>
              </button>
            )}

            <div className="flex items-center p-1 bg-[#181920] border border-[#2a2b34] rounded-xl">
              <button
                type="button"
                onClick={() => setViewMode('horizon')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  viewMode === 'horizon' ? 'bg-blue-600 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Horizon Scroll</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Grid className="w-3.5 h-3.5" />
                <span>Grid</span>
              </button>
            </div>

            {viewMode === 'horizon' && (
              <div className="hidden sm:flex items-center gap-1.5 ml-2">
                <button
                  type="button"
                  onClick={() => handleScroll('left')}
                  className="p-2.5 rounded-xl bg-[#181920] hover:bg-[#242530] border border-[#2a2b34] text-white transition-colors cursor-pointer"
                  aria-label="Scroll left"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleScroll('right')}
                  className="p-2.5 rounded-xl bg-[#181920] hover:bg-[#242530] border border-[#2a2b34] text-white transition-colors cursor-pointer"
                  aria-label="Scroll right"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Category Filter Pills (Solid styling) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-white text-black font-bold shadow-md'
                    : 'bg-[#15161c] text-neutral-400 hover:text-white border border-[#252630] hover:bg-[#1f2028]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* GALLERY VIEW: HORIZON SCROLL (Smooth sliding stream of phone-framed screenshots) */}
        {viewMode === 'horizon' ? (
          <div className="relative">
            <div
              ref={scrollContainerRef}
              className="flex gap-6 overflow-x-auto pb-8 pt-2 no-scrollbar scroll-smooth snap-x snap-mandatory"
            >
              {filteredScreens.map((screen) => (
                <div
                  key={screen.id}
                  className="w-[280px] sm:w-[320px] shrink-0 snap-start bg-[#121318] border border-[#23242e] rounded-3xl p-5 flex flex-col justify-between hover:border-[#3a3c4c] transition-all group"
                >
                  {/* Phone Hardware Frame */}
                  <div className="mb-4">
                    <PhoneHardwareFrame
                      src={screen.image}
                      alt={screen.title}
                      badge={screen.tag}
                      badgeColor={screen.tagColor}
                      onInspect={() => onSelectScreenshot(screen)}
                    />
                  </div>

                  {/* Card Details */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-neutral-400">
                        {screen.category}
                      </span>
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                    </div>

                    <h3 className="text-lg font-bold text-white font-display group-hover:text-blue-400 transition-colors">
                      {screen.title}
                    </h3>

                    <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                      {screen.description}
                    </p>

                    {/* Feature Highlights */}
                    <div className="pt-2 border-t border-[#1e1f28] space-y-1.5">
                      {screen.highlights.slice(0, 2).map((hl, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 text-[11px] text-neutral-300">
                          <CheckCircle2 className="w-3 h-3 text-green-500 shrink-0" />
                          <span className="truncate">{hl}</span>
                        </div>
                      ))}
                    </div>

                    {/* Inspect Button */}
                    <button
                      type="button"
                      onClick={() => onSelectScreenshot(screen)}
                      className="w-full mt-3 py-2.5 rounded-xl bg-[#1c1d25] hover:bg-blue-600 text-neutral-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-[#2a2b36] hover:border-blue-500"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                      <span>Full View Frame</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* GRID VIEW: Responsive multi-column layout */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredScreens.map((screen) => (
              <div
                key={screen.id}
                className="bg-[#121318] border border-[#23242e] rounded-3xl p-5 flex flex-col justify-between hover:border-[#3a3c4c] transition-all group"
              >
                <div className="mb-4">
                  <PhoneHardwareFrame
                    src={screen.image}
                    alt={screen.title}
                    badge={screen.tag}
                    badgeColor={screen.tagColor}
                    onInspect={() => onSelectScreenshot(screen)}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>{screen.category}</span>
                    <span className="px-2 py-0.5 rounded bg-[#1d1e27] text-white text-[10px]">
                      {screen.tag}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white font-display">
                    {screen.title}
                  </h3>

                  <p className="text-xs text-neutral-400 line-clamp-2">
                    {screen.description}
                  </p>

                  <button
                    type="button"
                    onClick={() => onSelectScreenshot(screen)}
                    className="w-full mt-3 py-2.5 rounded-xl bg-[#1c1d25] hover:bg-blue-600 text-neutral-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-[#2a2b36]"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>Inspect</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
