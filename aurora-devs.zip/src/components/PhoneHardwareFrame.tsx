import React from 'react';
import { Maximize2 } from 'lucide-react';

interface PhoneHardwareFrameProps {
  src: string;
  alt: string;
  className?: string;
  aspectRatio?: string; // default "9/19.5"
  onInspect?: () => void;
  badge?: string;
  badgeColor?: 'blue' | 'red' | 'green' | 'brown' | 'white';
  showGlare?: boolean;
}

export const PhoneHardwareFrame: React.FC<PhoneHardwareFrameProps> = ({
  src,
  alt,
  className = '',
  aspectRatio = 'aspect-[9/19.5]',
  onInspect,
  badge,
  badgeColor = 'blue',
  showGlare = true,
}) => {
  const getBadgeStyle = () => {
    switch (badgeColor) {
      case 'red':
        return 'bg-red-600 text-white';
      case 'green':
        return 'bg-green-600 text-white';
      case 'brown':
        return 'bg-[#3E2D27] text-white';
      case 'white':
        return 'bg-white text-black';
      case 'blue':
      default:
        return 'bg-blue-600 text-white';
    }
  };

  return (
    <div className={`relative group ${className}`}>
      {/* Outer Phone Bezel with Chamfered Edge */}
      <div className="relative rounded-[40px] p-[9px] bg-black border-2 border-[#2b2c31] shadow-2xl transition-transform duration-300 group-hover:scale-[1.015]">
        
        {/* Hardware side buttons */}
        <div className="absolute -left-[5px] top-24 w-[3px] h-10 bg-[#3a3b42] rounded-l-sm" />
        <div className="absolute -left-[5px] top-38 w-[3px] h-14 bg-[#3a3b42] rounded-l-sm" />
        <div className="absolute -right-[5px] top-28 w-[3px] h-16 bg-[#3a3b42] rounded-r-sm" />

        {/* Screen Bezel and Display Area */}
        <div className={`relative rounded-[32px] overflow-hidden bg-black ${aspectRatio} w-full`}>
          
          {/* Top Speaker Earpiece Slit */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-1 bg-[#1a1a1e] rounded-full z-30" />

          {/* Camera Punch Hole */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-black rounded-full border border-[#2a2a30] z-30 flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-[#0b101e] rounded-full" />
          </div>

          {/* Real Screenshot Image */}
          <img
            src={src}
            alt={alt}
            className="w-full h-full object-cover object-top select-none"
            loading="lazy"
            onError={(e) => {
              // Fallback if image fails
              (e.target as HTMLElement).style.opacity = '0.9';
            }}
          />

          {/* Subtle Glass Reflection / Glare (No gradients, simple diagonal overlay line) */}
          {showGlare && (
            <div className="absolute inset-0 pointer-events-none opacity-20 border-r border-white/30 transform -skew-x-12 translate-x-40" />
          )}

          {/* Badge if provided */}
          {badge && (
            <div className="absolute bottom-3 left-3 z-30 pointer-events-none">
              <span className={`px-2.5 py-1 text-[11px] font-bold rounded-md shadow-md ${getBadgeStyle()}`}>
                {badge}
              </span>
            </div>
          )}

          {/* Hover Inspect Overlay */}
          {onInspect && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onInspect();
              }}
              className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 text-white font-medium text-xs z-30 cursor-pointer"
              title="Click to expand full screen"
            >
              <div className="p-3 rounded-full bg-blue-600 text-white shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                <Maximize2 className="w-5 h-5" />
              </div>
              <span className="font-semibold tracking-wide">View Full Screen</span>
            </button>
          )}

        </div>
      </div>
    </div>
  );
};
