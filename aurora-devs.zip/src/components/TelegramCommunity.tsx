import React from 'react';
import { Send, MessageCircle, ExternalLink, Crown, Sparkles } from 'lucide-react';
import { TEAM_MEMBERS, TELEGRAM_CHANNELS } from '../data/defaultData';

interface TelegramCommunityProps {
  updatesLink?: string;
  supportLink?: string;
}

export const TelegramCommunity: React.FC<TelegramCommunityProps> = ({
  updatesLink = TELEGRAM_CHANNELS.updates,
  supportLink = TELEGRAM_CHANNELS.support
}) => {
  return (
    <section id="community" className="py-24 bg-[#0a0b0e] text-white relative border-b border-[#1f2026]">
      
      {/* Background depth ambiance (solid dark, no gradients) */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-96 bg-[#151722] rounded-full blur-[140px] pointer-events-none -z-10 opacity-50" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Banner Card matching Slide 4 ("Join To Our Telegram") - NO GRADIENTS */}
        <div className="relative rounded-3xl bg-[#121318] border border-[#242532] p-8 sm:p-14 mb-16 overflow-hidden">
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Column: Text & Action */}
            <div className="lg:col-span-8 space-y-5 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md bg-[#181a24] border border-[#2c2e40] text-blue-400 text-xs font-bold font-mono">
                <Send className="w-3.5 h-3.5 text-blue-500" />
                <span>OFFICIAL TELEGRAM CHANNEL</span>
              </div>

              <h2 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white font-display leading-tight">
                Join To Our <span className="text-blue-500">Telegram</span>
              </h2>

              <p className="text-base sm:text-xl text-neutral-300 font-medium">
                To get updates for Your device
              </p>

              <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
                Get instant notifications for new build releases, OTA changelogs, test kernels, 
                and direct support from the maintainers.
              </p>

              {/* Action Buttons (Solid Red & Blue, NO GRADIENTS) */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5">
                <a
                  href={updatesLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-7 py-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition flex items-center justify-center gap-2.5 cursor-pointer active:scale-95"
                >
                  <Send className="w-4 h-4" />
                  <span>Join Now (@Aurora_update)</span>
                </a>

                <a
                  href={supportLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-6 py-4 rounded-xl bg-[#1a1b24] hover:bg-[#252634] text-neutral-200 hover:text-white font-bold text-sm border border-[#2d2f40] transition flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <MessageCircle className="w-4 h-4 text-red-500" />
                  <span>Support Group (@Avroradevs)</span>
                </a>
              </div>
            </div>

            {/* Right Column: Aurora Emblem from Slide 4 */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center">
              <div className="relative p-2">
                <div className="w-44 h-44 sm:w-48 sm:h-48 rounded-full p-2 bg-[#181922] border-2 border-[#2f3142] flex items-center justify-center">
                  <div className="w-full h-full rounded-full bg-[#0c0d10] flex flex-col items-center justify-center text-white border border-[#252632] overflow-hidden relative">
                    <span className="font-extrabold tracking-tighter text-2xl uppercase font-brand text-white">
                      Aurora
                    </span>
                    <span className="font-bold tracking-widest text-[9px] uppercase border-t border-[#2a2b36] pt-1 mt-1 text-neutral-400">
                      DEVELOPERS
                    </span>
                    <span className="text-[10px] text-blue-400 mt-2 font-mono">
                      @Aurora_update
                    </span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Development Team Credits (From User Details) */}
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <h3 className="text-2xl font-bold text-white font-display">
              Core Development Team
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 mt-1">
              The passionate developers and designers crafting the Aurora experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TEAM_MEMBERS.map((member) => (
              <div
                key={member.name}
                className="rounded-3xl bg-[#121318] border border-[#23242e] p-6 hover:border-[#353745] transition text-center flex flex-col items-center justify-between"
              >
                <div className="flex flex-col items-center">
                  {/* Member Avatar Pill (Solid colors) */}
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-lg text-white mb-4 shadow-md ${
                    member.accent === 'red'
                      ? 'bg-red-600'
                      : member.accent === 'green'
                      ? 'bg-emerald-600'
                      : 'bg-blue-600'
                  }`}>
                    {member.avatarText}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-white text-base">{member.name}</h4>
                    {member.role.includes('OWNER') && (
                      <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                    )}
                  </div>

                  <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md mt-1 mb-2 ${
                    member.accent === 'red' 
                      ? 'text-red-400 bg-[#251518] border border-[#44232a]' 
                      : 'text-blue-400 bg-[#151d2e] border border-[#233554]'
                  }`}>
                    {member.role}
                  </span>

                  <p className="text-xs text-neutral-400 mt-1">
                    {member.tagline}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#1e1f28] w-full flex justify-center">
                  <a
                    href={member.telegramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-400 hover:text-blue-300 hover:underline"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{member.handle}</span>
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
