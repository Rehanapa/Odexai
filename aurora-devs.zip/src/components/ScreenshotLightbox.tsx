import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Download, Sparkles } from 'lucide-react';
import { ScreenshotGalleryItem } from '../types';
import { PhoneHardwareFrame } from './PhoneHardwareFrame';
import { COLOROS_SCREENSHOTS } from '../data/defaultData';

interface ScreenshotLightboxProps {
  item: ScreenshotGalleryItem | null;
  items?: ScreenshotGalleryItem[];
  onClose: () => void;
  onSelect?: (item: ScreenshotGalleryItem) => void;
  onSelectNext?: (currentItem: ScreenshotGalleryItem) => void;
  onSelectPrev?: (currentItem: ScreenshotGalleryItem) => void;
  onScrollToDevices?: () => void;
}

export const ScreenshotLightbox: React.FC<ScreenshotLightboxProps> = ({
  item,
  items,
  onClose,
  onSelect,
  onSelectNext,
  onSelectPrev,
  onScrollToDevices
}) => {
  const galleryItems = items && items.length > 0 ? items : COLOROS_SCREENSHOTS;

  const currentIndex = item && galleryItems.length > 0
    ? galleryItems.findIndex((i) => i.id === item.id)
    : 0;
  const validIndex = currentIndex >= 0 ? currentIndex : 0;

  const handleNext = () => {
    if (onSelectNext && item) {
      onSelectNext(item);
      return;
    }
    if (galleryItems.length > 0 && onSelect) {
      const nextIndex = (validIndex + 1) % galleryItems.length;
      onSelect(galleryItems[nextIndex]);
    }
  };

  const handlePrev = () => {
    if (onSelectPrev && item) {
      onSelectPrev(item);
      return;
    }
    if (galleryItems.length > 0 && onSelect) {
      const prevIndex = (validIndex - 1 + galleryItems.length) % galleryItems.length;
      onSelect(galleryItems[prevIndex]);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!item) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [item, galleryItems, validIndex]);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-5xl bg-[#121316] border border-[#2b2c34] rounded-3xl p-6 sm:p-8 shadow-2xl text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Control Bar */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-[#25262c]">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-md text-xs font-bold bg-blue-600 text-white">
              {item.category}
            </span>
            <span className="text-neutral-400 text-xs font-mono">
              {galleryItems.length > 0 ? validIndex + 1 : 1} of {galleryItems.length || 1}
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-[#202126] hover:bg-[#2e3038] text-neutral-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Left Details, Right Framed Phone */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Left Column: Information */}
          <div className="md:col-span-6 space-y-5">
            <div>
              <h3 className="text-2xl sm:text-3xl font-bold font-display text-white mb-2">
                {item.title}
              </h3>
              <p className="text-neutral-300 text-sm leading-relaxed">
                {item.description}
              </p>
            </div>

            {/* Highlights List */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                Key Features in this Screen
              </div>
              <div className="space-y-2">
                {item.highlights.map((h, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 p-2.5 rounded-lg bg-[#1a1b20] border border-[#282931] text-xs text-neutral-200"
                  >
                    <Sparkles className="w-4 h-4 text-blue-500 shrink-0" />
                    <span>{h}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onScrollToDevices?.();
                }}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md"
              >
                <Download className="w-4 h-4" />
                <span>Get ROM for Your Device</span>
              </button>
              <a
                href="https://t.me/Aurora_update"
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-xl bg-[#202126] hover:bg-[#2b2c34] text-white text-xs font-bold border border-[#33343d] flex items-center gap-2 cursor-pointer"
              >
                <span>Telegram Channel</span>
              </a>
            </div>
          </div>

          {/* Right Column: Phone Frame in Focus */}
          <div className="md:col-span-6 flex flex-col items-center justify-center relative">
            <div className="w-[260px] sm:w-[300px]">
              <PhoneHardwareFrame
                src={item.image}
                alt={item.title}
                badge={item.tag}
                badgeColor={item.tagColor}
                showGlare={false}
              />
            </div>

            {/* Navigation Arrows */}
            <div className="flex items-center justify-center gap-4 mt-6">
              <button
                type="button"
                onClick={handlePrev}
                className="p-3 rounded-full bg-[#1c1d22] hover:bg-[#2b2c34] border border-[#30313b] text-white transition-colors cursor-pointer"
                title="Previous Screenshot (Left Arrow)"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <span className="text-xs text-neutral-400 font-mono">
                Use &larr; &rarr; to navigate
              </span>
              <button
                type="button"
                onClick={handleNext}
                className="p-3 rounded-full bg-[#1c1d22] hover:bg-[#2b2c34] border border-[#30313b] text-white transition-colors cursor-pointer"
                title="Next Screenshot (Right Arrow)"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
