import React, { useState } from 'react';
import { RomRelease, RomReview, ScreenshotGalleryItem } from '../types';
import { 
  Shield, 
  Lock, 
  Plus, 
  Trash2, 
  Check, 
  RefreshCcw, 
  Send, 
  Layers, 
  MessageSquare, 
  Star,
  Image as ImageIcon,
  Upload,
  ExternalLink
} from 'lucide-react';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  roms: RomRelease[];
  reviews: RomReview[];
  screenshots?: ScreenshotGalleryItem[];
  onUpdateRoms: (roms: RomRelease[]) => void;
  onUpdateReviews: (reviews: RomReview[]) => void;
  onUpdateScreenshots?: (screenshots: ScreenshotGalleryItem[]) => void;
  onResetToDefaults: () => void;
  telegramLink: string;
  supportLink: string;
  onUpdateTelegramLinks: (updates: string, support: string) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  roms,
  reviews,
  screenshots = [],
  onUpdateRoms,
  onUpdateReviews,
  onUpdateScreenshots,
  onResetToDefaults,
  telegramLink,
  supportLink,
  onUpdateTelegramLinks
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState(false);
  const [activeTab, setActiveTab] = useState<'roms' | 'reviews' | 'screenshots' | 'telegram'>('roms');

  // New ROM Form State
  const [showAddRomForm, setShowAddRomForm] = useState(false);
  const [newRomName, setNewRomName] = useState('');
  const [newRomCodename, setNewRomCodename] = useState('ginkgo');
  const [newRomDeviceModel, setNewRomDeviceModel] = useState('Redmi Note 8');
  const [newRomChipset, setNewRomChipset] = useState('Qualcomm Snapdragon 665');
  const [newRomVersion, setNewRomVersion] = useState('v15.0.3 Stable');
  const [newRomSize, setNewRomSize] = useState('2.9 GB');
  const [newRomTelegramUrl, setNewRomTelegramUrl] = useState('https://t.me/Aurora_update');
  const [newRomChangelog, setNewRomChangelog] = useState('Upstream kernel patch\nFixed camera shutter sound\nImproved battery life');
  const [newRomMaintainer, setNewRomMaintainer] = useState('@isaec_newton');

  // New Screenshot Form State
  const [showAddScreenshotForm, setShowAddScreenshotForm] = useState(false);
  const [screenshotTitle, setScreenshotTitle] = useState('');
  const [screenshotCategory, setScreenshotCategory] = useState<string>('System UI');
  const [screenshotTag, setScreenshotTag] = useState('New Feature');
  const [screenshotTagColor, setScreenshotTagColor] = useState<'blue' | 'red' | 'green' | 'brown' | 'white'>('blue');
  const [screenshotDescription, setScreenshotDescription] = useState('');
  const [screenshotHighlights, setScreenshotHighlights] = useState('');
  const [screenshotImageUrl, setScreenshotImageUrl] = useState('');
  const [screenshotImagePreview, setScreenshotImagePreview] = useState<string | null>(null);
  const [screenshotFileError, setScreenshotFileError] = useState<string | null>(null);

  // Telegram Link Temp Edit State
  const [tempTelegram, setTempTelegram] = useState(telegramLink);
  const [tempSupport, setTempSupport] = useState(supportLink);
  const [telegramSavedNotice, setTelegramSavedNotice] = useState(false);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput.toLowerCase() === 'aurora' || passwordInput === 'admin123') {
      setIsAuthenticated(true);
      setAuthError(false);
    } else {
      setAuthError(true);
    }
  };

  const handleAddRom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRomName.trim()) return;

    const newRom: RomRelease = {
      id: `aurora-${Date.now()}`,
      name: newRomName.trim(),
      codename: newRomCodename.trim(),
      deviceModel: newRomDeviceModel.trim(),
      chipset: newRomChipset.trim(),
      androidVersion: 'Android 14 / ColorOS 15',
      colorOsVersion: newRomVersion.trim(),
      status: 'Official',
      releaseDate: new Date().toISOString().split('T')[0],
      fileSize: newRomSize.trim(),
      downloadTelegramUrl: newRomTelegramUrl.trim(),
      supportGroupUrl: tempSupport,
      description: `Official Aurora ColorOS port tailored for ${newRomDeviceModel}.`,
      changelog: newRomChangelog.split('\n').map(s => s.trim()).filter(Boolean),
      bannerGradient: 'solid-blue',
      accentColor: '#2563EB',
      maintainer: newRomMaintainer.trim()
    };

    onUpdateRoms([newRom, ...roms]);
    setShowAddRomForm(false);
    setNewRomName('');
  };

  const handleDeleteRom = (id: string) => {
    if (window.confirm('Are you sure you want to delete this ROM?')) {
      onUpdateRoms(roms.filter(r => r.id !== id));
    }
  };

  const handleDeleteReview = (id: string) => {
    onUpdateReviews(reviews.filter(r => r.id !== id));
  };

  const handleToggleVerifyReview = (id: string) => {
    onUpdateReviews(
      reviews.map(r => r.id === id ? { ...r, verified: !r.verified } : r)
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setScreenshotFileError('Please select a valid image file (PNG, JPG, WebP).');
      return;
    }
    setScreenshotFileError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setScreenshotImagePreview(result);
      setScreenshotImageUrl(result);
    };
    reader.readAsDataURL(file);
  };

  const handleAddScreenshot = (e: React.FormEvent) => {
    e.preventDefault();
    const finalImage = screenshotImagePreview || screenshotImageUrl.trim();
    if (!finalImage) {
      setScreenshotFileError('Please upload an image or provide an image URL/path.');
      return;
    }

    const newId = `screen-${Date.now()}`;
    const highlightsArray = screenshotHighlights
      .split('\n')
      .map(h => h.trim())
      .filter(Boolean);

    const newScreenshot: ScreenshotGalleryItem = {
      id: newId,
      title: screenshotTitle.trim() || 'Aurora ColorOS Interface',
      category: screenshotCategory,
      tag: screenshotTag.trim() || 'New Feature',
      tagColor: screenshotTagColor,
      image: finalImage,
      description: screenshotDescription.trim() || 'Official Aurora ColorOS system screenshot.',
      highlights: highlightsArray.length > 0 ? highlightsArray : ['Smooth performance', 'Ultra-fluid UI']
    };

    if (onUpdateScreenshots) {
      onUpdateScreenshots([newScreenshot, ...screenshots]);
    }

    // Reset Form
    setScreenshotTitle('');
    setScreenshotCategory('System UI');
    setScreenshotTag('New Feature');
    setScreenshotTagColor('blue');
    setScreenshotDescription('');
    setScreenshotHighlights('');
    setScreenshotImageUrl('');
    setScreenshotImagePreview(null);
    setScreenshotFileError(null);
    setShowAddScreenshotForm(false);
  };

  const handleDeleteScreenshot = (id: string) => {
    if (!window.confirm('Are you sure you want to delete this screenshot from the gallery?')) return;
    if (onUpdateScreenshots) {
      onUpdateScreenshots(screenshots.filter(s => s.id !== id));
    }
  };

  const handleSaveTelegramLinks = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateTelegramLinks(tempTelegram, tempSupport);
    setTelegramSavedNotice(true);
    setTimeout(() => setTelegramSavedNotice(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl rounded-3xl bg-[#121318] p-6 sm:p-8 shadow-2xl border border-[#262836] text-white max-h-[92vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#21232f] mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-display">
                Aurora DEVs Admin Panel
              </h3>
              <p className="text-xs text-neutral-400">Live Management Dashboard & System Controls</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-[#1c1d27] text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Not Authenticated: Show Password Prompt */}
        {!isAuthenticated ? (
          <div className="py-12 max-w-sm mx-auto text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-[#191b24] text-neutral-300 flex items-center justify-center mx-auto mb-2 border border-[#2a2c3a]">
              <Lock className="w-6 h-6 text-blue-500" />
            </div>
            <h4 className="text-lg font-bold text-white">Administrator Access</h4>
            <p className="text-xs text-neutral-400">
              Enter the passcode to manage ROM downloads, community reviews, and Telegram channel routes.
            </p>

            <form onSubmit={handleLogin} className="space-y-3 pt-2">
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter passcode (hint: aurora)"
                className="w-full px-4 py-2.5 text-xs text-center font-mono rounded-xl bg-[#181922] border border-[#2b2d3c] text-white focus:outline-none focus:border-blue-500 shadow-xs"
                autoFocus
              />

              {authError && (
                <div className="text-[11px] text-red-400 font-semibold">
                  Incorrect passcode. (Try &quot;aurora&quot;)
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow-md cursor-pointer"
              >
                Unlock Dashboard
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated: Admin Tabs */
          <div className="space-y-6">
            
            {/* Nav Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#21232f] pb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('roms')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'roms' 
                      ? 'bg-blue-600 text-white shadow-sm' 
                      : 'bg-[#181922] text-neutral-300 hover:bg-[#222430]'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>ROM Releases ({roms.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('reviews')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'reviews' 
                      ? 'bg-blue-600 text-white shadow-sm' 
                      : 'bg-[#181922] text-neutral-300 hover:bg-[#222430]'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Reviews ({reviews.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('screenshots')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'screenshots' 
                      ? 'bg-blue-600 text-white shadow-sm' 
                      : 'bg-[#181922] text-neutral-300 hover:bg-[#222430]'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Screenshots ({screenshots.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('telegram')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'telegram' 
                      ? 'bg-blue-600 text-white shadow-sm' 
                      : 'bg-[#181922] text-neutral-300 hover:bg-[#222430]'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Telegram Config</span>
                </button>
              </div>

              {/* Reset to Curated Seed button */}
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Reset all ROMs and reviews back to curated default state?')) {
                    onResetToDefaults();
                  }
                }}
                className="px-3 py-1.5 rounded-xl text-[11px] font-semibold text-neutral-400 hover:text-red-400 hover:bg-[#251518] border border-[#2b2d3c] transition flex items-center gap-1 cursor-pointer"
              >
                <RefreshCcw className="w-3 h-3" />
                <span>Reset Seed Data</span>
              </button>
            </div>

            {/* TAB 1: ROM Releases */}
            {activeTab === 'roms' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white">Installed ROM Releases</h4>
                  <button
                    type="button"
                    onClick={() => setShowAddRomForm(!showAddRomForm)}
                    className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddRomForm ? 'Cancel' : 'Add New ROM'}</span>
                  </button>
                </div>

                {/* Add New ROM Sub-Form */}
                {showAddRomForm && (
                  <form onSubmit={handleAddRom} className="p-4 rounded-2xl bg-[#161720] border border-[#2c2e3e] space-y-3 text-xs animate-in fade-in duration-200">
                    <div className="font-bold text-blue-400 text-sm">Create New ROM Release</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Release Title *</label>
                        <input
                          type="text"
                          required
                          value={newRomName}
                          onChange={(e) => setNewRomName(e.target.value)}
                          placeholder="Aurora ColorOS 15.0 Hotfix"
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Device Model *</label>
                        <input
                          type="text"
                          required
                          value={newRomDeviceModel}
                          onChange={(e) => setNewRomDeviceModel(e.target.value)}
                          placeholder="Redmi Note 8"
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Codename *</label>
                        <input
                          type="text"
                          required
                          value={newRomCodename}
                          onChange={(e) => setNewRomCodename(e.target.value)}
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Version *</label>
                        <input
                          type="text"
                          required
                          value={newRomVersion}
                          onChange={(e) => setNewRomVersion(e.target.value)}
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Maintainer *</label>
                        <input
                          type="text"
                          required
                          value={newRomMaintainer}
                          onChange={(e) => setNewRomMaintainer(e.target.value)}
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-semibold mb-1">Telegram Download URL *</label>
                      <input
                        type="url"
                        required
                        value={newRomTelegramUrl}
                        onChange={(e) => setNewRomTelegramUrl(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg font-mono text-[11px] text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-semibold mb-1">Changelog (1 per line)</label>
                      <textarea
                        rows={3}
                        value={newRomChangelog}
                        onChange={(e) => setNewRomChangelog(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white resize-none"
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setShowAddRomForm(false)}
                        className="px-3 py-1.5 rounded-lg text-neutral-400 hover:bg-[#222430] font-semibold cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 rounded-lg bg-blue-600 text-white font-bold hover:bg-blue-700 cursor-pointer"
                      >
                        Publish ROM
                      </button>
                    </div>
                  </form>
                )}

                {/* List of ROMs */}
                <div className="space-y-2">
                  {roms.map((rom) => (
                    <div
                      key={rom.id}
                      className="p-3.5 rounded-2xl bg-[#161720] border border-[#262836] flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="font-bold text-white flex items-center gap-2">
                          <span>{rom.name}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#1f2230] text-blue-400 font-mono">
                            [{rom.codename}]
                          </span>
                        </div>
                        <div className="text-neutral-400 text-[11px]">
                          {rom.colorOsVersion} • Size: {rom.fileSize} • Maintainer: {rom.maintainer}
                        </div>
                        <a
                          href={rom.downloadTelegramUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] text-blue-400 hover:underline font-mono truncate block max-w-md"
                        >
                          {rom.downloadTelegramUrl}
                        </a>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleDeleteRom(rom.id)}
                          className="p-2 rounded-xl text-neutral-400 hover:text-red-400 hover:bg-[#251518] transition cursor-pointer"
                          title="Delete ROM"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 2: Reviews Management */}
            {activeTab === 'reviews' && (
              <div className="space-y-3">
                <div className="text-sm font-bold text-white">Moderate User Reviews</div>
                <div className="space-y-2">
                  {reviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-3.5 rounded-2xl bg-[#161720] border border-[#262836] flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{rev.author}</span>
                          <span className="text-neutral-400">({rev.deviceName} • [{rev.deviceCodename}])</span>
                          <div className="flex items-center gap-0.5 text-amber-400 font-bold">
                            <Star className="w-3 h-3 fill-amber-400" />
                            <span>{rev.rating}.0</span>
                          </div>
                        </div>
                        <div className="font-semibold text-white">&ldquo;{rev.title}&rdquo;</div>
                        <div className="text-neutral-400 text-[11px] max-w-xl">{rev.comment}</div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleVerifyReview(rev.id)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                            rev.verified 
                              ? 'bg-[#121c17] text-emerald-400 border-[#1f3529]' 
                              : 'bg-[#1b1c24] text-neutral-400 border-[#2b2d3c]'
                          }`}
                        >
                          {rev.verified ? 'Verified Flasher' : 'Unverified'}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteReview(rev.id)}
                          className="p-1.5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-[#251518] transition cursor-pointer"
                          title="Delete Review"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: Screenshots Gallery Management */}
            {activeTab === 'screenshots' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>Screenshot Gallery Management</span>
                      <span className="text-xs px-2 py-0.5 rounded-md bg-[#1f2230] text-blue-400 font-mono">
                        {screenshots.length} items
                      </span>
                    </h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Upload new real ColorOS ROM screenshots or delete items from the public gallery.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddScreenshotForm(!showAddScreenshotForm)}
                    className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddScreenshotForm ? 'Cancel' : 'Upload / Add Screenshot'}</span>
                  </button>
                </div>

                {/* Add/Upload Screenshot Form */}
                {showAddScreenshotForm && (
                  <form onSubmit={handleAddScreenshot} className="p-4 sm:p-5 rounded-2xl bg-[#161720] border border-[#2c2e3e] space-y-4 text-xs animate-in fade-in duration-200">
                    <div className="font-bold text-blue-400 text-sm flex items-center gap-1.5">
                      <Upload className="w-4 h-4" />
                      <span>Upload New Screenshot to Gallery</span>
                    </div>

                    {/* Image Upload / Input Row */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                      <div className="space-y-2">
                        <label className="block text-neutral-300 font-semibold">
                          Upload Image File * <span className="text-neutral-500 font-normal">(PNG, JPG, WebP)</span>
                        </label>
                        <div className="relative border-2 border-dashed border-[#2e3042] hover:border-blue-500 rounded-xl p-4 text-center bg-[#13141b] transition">
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleFileUpload}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                          <Upload className="w-6 h-6 text-neutral-400 mx-auto mb-1.5" />
                          <p className="text-[11px] font-semibold text-neutral-300">
                            Click or drag an image here to upload
                          </p>
                          <p className="text-[10px] text-neutral-500 mt-0.5">
                            Files are processed locally & displayed immediately
                          </p>
                        </div>

                        <div className="pt-1">
                          <label className="block text-neutral-300 font-semibold mb-1">
                            Or Enter Image URL / Path
                          </label>
                          <input
                            type="text"
                            value={screenshotImageUrl}
                            onChange={(e) => {
                              setScreenshotImageUrl(e.target.value);
                              if (!screenshotImagePreview) setScreenshotFileError(null);
                            }}
                            placeholder="/screenshots/... or https://..."
                            className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white font-mono text-[11px]"
                          />
                        </div>

                        {screenshotFileError && (
                          <div className="text-[11px] text-red-400 font-semibold">
                            {screenshotFileError}
                          </div>
                        )}
                      </div>

                      {/* Image Preview Box */}
                      <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-[#13141b] border border-[#262838] min-h-[170px]">
                        <div className="text-[10px] uppercase font-bold text-neutral-400 mb-2">Live Image Preview</div>
                        {screenshotImagePreview || screenshotImageUrl ? (
                          <div className="relative group max-h-48 overflow-hidden rounded-lg border border-[#333544]">
                            <img
                              src={screenshotImagePreview || screenshotImageUrl}
                              alt="Screenshot Preview"
                              className="max-h-40 w-auto object-contain rounded-md"
                              onError={() => setScreenshotFileError('Unable to load image from provided URL.')}
                              onLoad={() => setScreenshotFileError(null)}
                            />
                          </div>
                        ) : (
                          <div className="text-center text-neutral-500 py-6">
                            <ImageIcon className="w-8 h-8 mx-auto mb-1 opacity-40" />
                            <p className="text-[11px]">No image selected yet</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Metadata Fields */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Title *</label>
                        <input
                          type="text"
                          required
                          value={screenshotTitle}
                          onChange={(e) => setScreenshotTitle(e.target.value)}
                          placeholder="e.g. ColorOS 15 Lock Screen Flux"
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Category *</label>
                        <select
                          value={screenshotCategory}
                          onChange={(e) => setScreenshotCategory(e.target.value)}
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white cursor-pointer"
                        >
                          <option value="System UI">System UI</option>
                          <option value="Control Center">Control Center</option>
                          <option value="Lock Screen">Lock Screen</option>
                          <option value="Settings">Settings</option>
                          <option value="Personalization">Personalization</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Feature Tag</label>
                        <input
                          type="text"
                          value={screenshotTag}
                          onChange={(e) => setScreenshotTag(e.target.value)}
                          placeholder="e.g. Fluid Cloud, Dolby Atmos"
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Tag Accent Color</label>
                        <select
                          value={screenshotTagColor}
                          onChange={(e) => setScreenshotTagColor(e.target.value as any)}
                          className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white cursor-pointer"
                        >
                          <option value="blue">Blue Accent</option>
                          <option value="red">Red Accent</option>
                          <option value="green">Green Accent</option>
                          <option value="brown">Brown Accent</option>
                          <option value="white">White Neutral</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-semibold mb-1">Description</label>
                      <textarea
                        rows={2}
                        value={screenshotDescription}
                        onChange={(e) => setScreenshotDescription(e.target.value)}
                        placeholder="Short summary of this screen and what makes it special..."
                        className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-semibold mb-1">
                        Highlights <span className="text-neutral-500 font-normal">(One key highlight per line)</span>
                      </label>
                      <textarea
                        rows={2}
                        value={screenshotHighlights}
                        onChange={(e) => setScreenshotHighlights(e.target.value)}
                        placeholder="Aqua Dynamics notification pill&#10;Zero framedrop transitions&#10;Live Gaussian blur"
                        className="w-full px-3 py-1.5 bg-[#1b1c26] border border-[#2e3040] rounded-lg text-white font-mono text-[11px]"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddScreenshotForm(false)}
                        className="px-3.5 py-1.5 rounded-lg text-neutral-400 hover:bg-[#222430] font-semibold cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 rounded-lg bg-blue-600 text-white font-bold hover:bg-blue-700 cursor-pointer shadow-md"
                      >
                        Publish to Gallery
                      </button>
                    </div>
                  </form>
                )}

                {/* Screenshots List */}
                {screenshots.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl bg-[#15161f] border border-[#252736] text-neutral-400">
                    <ImageIcon className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p className="font-semibold text-white">No screenshots currently in gallery</p>
                    <p className="text-xs text-neutral-500 mt-1">Upload an image or reset seed data to restore official gallery.</p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {screenshots.map((screen) => (
                      <div
                        key={screen.id}
                        className="p-3.5 rounded-2xl bg-[#161720] border border-[#262836] flex items-center justify-between gap-3 text-xs hover:border-[#383a4c] transition"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          {/* Thumbnail */}
                          <div className="w-14 h-20 rounded-xl bg-[#0d0e12] border border-[#2b2d3d] overflow-hidden shrink-0 flex items-center justify-center">
                            <img
                              src={screen.image}
                              alt={screen.title}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = 'none';
                              }}
                            />
                          </div>

                          {/* Info */}
                          <div className="space-y-1 min-w-0">
                            <div className="font-bold text-white flex items-center gap-2 flex-wrap">
                              <span className="truncate">{screen.title}</span>
                              <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#1f2230] text-blue-400 font-mono">
                                {screen.category}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#251f22] text-red-400 font-mono">
                                {screen.tag}
                              </span>
                            </div>
                            <div className="text-neutral-400 text-[11px] line-clamp-1">
                              {screen.description}
                            </div>
                            {screen.highlights && screen.highlights.length > 0 && (
                              <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                                {screen.highlights.slice(0, 3).map((hl, i) => (
                                  <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-[#1c1d27] text-neutral-300">
                                    • {hl}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <a
                            href={screen.image}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 rounded-xl text-neutral-400 hover:text-blue-400 hover:bg-[#1a2233] transition cursor-pointer"
                            title="Open full image in new tab"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                          <button
                            type="button"
                            onClick={() => handleDeleteScreenshot(screen.id)}
                            className="p-2 rounded-xl text-neutral-400 hover:text-red-400 hover:bg-[#251518] transition cursor-pointer"
                            title="Delete screenshot from gallery"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: Telegram Configuration */}
            {activeTab === 'telegram' && (
              <form onSubmit={handleSaveTelegramLinks} className="space-y-4 max-w-md text-xs">
                <div className="text-sm font-bold text-white">Telegram Destination Links</div>
                <p className="text-neutral-400">Update where the user download and community buttons redirect to.</p>

                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">Official Updates Channel URL</label>
                  <input
                    type="url"
                    value={tempTelegram}
                    onChange={(e) => setTempTelegram(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-[#1b1c26] border border-[#2e3040] font-mono text-white"
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 font-semibold mb-1">Support Group URL</label>
                  <input
                    type="url"
                    value={tempSupport}
                    onChange={(e) => setTempSupport(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-[#1b1c26] border border-[#2e3040] font-mono text-white"
                  />
                </div>

                <div className="pt-2 flex items-center gap-3">
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md cursor-pointer"
                  >
                    Save Changes
                  </button>
                  {telegramSavedNotice && (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-4 h-4" /> Updated successfully!
                    </span>
                  )}
                </div>
              </form>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
