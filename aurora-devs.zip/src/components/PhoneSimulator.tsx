import React, { useState, useRef } from 'react';
import { 
  Wifi, 
  Battery, 
  Volume2, 
  Sun, 
  Moon, 
  Search, 
  Phone, 
  MessageSquare, 
  Camera, 
  RotateCw, 
  Check, 
  Flashlight, 
  Plane, 
  Bluetooth, 
  MapPin, 
  Share2, 
  Sparkles,
  Layers,
  Info,
  Sliders,
  Maximize2
} from 'lucide-react';
import { GalleryScreenType } from '../types';

interface PhoneSimulatorProps {
  activeScreen?: GalleryScreenType;
  onScreenChange?: (screen: GalleryScreenType) => void;
  interactiveControls?: boolean;
  scale?: number;
  initialTilt?: 'flat' | 'left' | 'right' | 'hero';
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  activeScreen: controlledScreen,
  onScreenChange,
  interactiveControls = true,
  scale = 1,
  initialTilt = 'flat'
}) => {
  const [internalScreen, setInternalScreen] = useState<GalleryScreenType>('homescreen');
  const screen = controlledScreen || internalScreen;
  const setScreen = (s: GalleryScreenType) => {
    setInternalScreen(s);
    if (onScreenChange) onScreenChange(s);
  };

  // 3D Tilt State
  const [tiltMode, setTiltMode] = useState<'flat' | 'left' | 'right' | 'hero'>(initialTilt);
  const [mouseRotation, setMouseRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Phone Interactive States
  const [wifiEnabled, setWifiEnabled] = useState(true);
  const [bluetoothEnabled, setBluetoothEnabled] = useState(true);
  const [flashlightEnabled, setFlashlightEnabled] = useState(false);
  const [dndEnabled, setDndEnabled] = useState(false);
  const [brightness, setBrightness] = useState(78);
  const [volume, setVolume] = useState(65);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanedSuccess, setCleanedSuccess] = useState(false);
  const [isLocked, setIsLocked] = useState(screen === 'lockscreen');
  const [activeNotification, setActiveNotification] = useState<boolean>(true);

  // Mouse move handler for smooth 3D parallax
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = -((y - centerY) / centerY) * 10;
    const rotateY = ((x - centerX) / centerX) * 12;
    setMouseRotation({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setMouseRotation({ x: 0, y: 0 });
  };

  const handleCleanUp = () => {
    setIsCleaning(true);
    setTimeout(() => {
      setIsCleaning(false);
      setCleanedSuccess(true);
      setTimeout(() => setCleanedSuccess(false), 2500);
    }, 1000);
  };

  // Base rotation depending on preset mode
  const getBaseRotation = () => {
    switch (tiltMode) {
      case 'left':
        return { x: 8, y: -18, z: 2 };
      case 'right':
        return { x: 8, y: 18, z: -2 };
      case 'hero':
        return { x: 12, y: -12, z: 3 };
      default:
        return { x: 0, y: 0, z: 0 };
    }
  };

  const baseRot = getBaseRotation();
  const currentRotX = isHovered ? baseRot.x + mouseRotation.x : baseRot.x;
  const currentRotY = isHovered ? baseRot.y + mouseRotation.y : baseRot.y;

  return (
    <div className="flex flex-col items-center select-none">
      {/* Screen Selector Pills for Desktop/Tablet */}
      {interactiveControls && (
        <div className="mb-4 flex flex-wrap items-center justify-center gap-1.5 p-1.5 rounded-2xl bg-white/80 backdrop-blur-md border border-slate-200/80 shadow-sm text-xs font-medium text-slate-600 max-w-lg">
          <button
            type="button"
            onClick={() => setScreen('homescreen')}
            className={`px-3 py-1.5 rounded-xl transition ${screen === 'homescreen' ? 'bg-blue-600 text-white font-semibold shadow-sm' : 'hover:bg-slate-100'}`}
          >
            Homescreen
          </button>
          <button
            type="button"
            onClick={() => setScreen('lockscreen')}
            className={`px-3 py-1.5 rounded-xl transition ${screen === 'lockscreen' ? 'bg-blue-600 text-white font-semibold shadow-sm' : 'hover:bg-slate-100'}`}
          >
            Lockscreen
          </button>
          <button
            type="button"
            onClick={() => setScreen('controlcenter')}
            className={`px-3 py-1.5 rounded-xl transition ${screen === 'controlcenter' ? 'bg-blue-600 text-white font-semibold shadow-sm' : 'hover:bg-slate-100'}`}
          >
            Control Center
          </button>
          <button
            type="button"
            onClick={() => setScreen('wallpapers')}
            className={`px-3 py-1.5 rounded-xl transition ${screen === 'wallpapers' ? 'bg-blue-600 text-white font-semibold shadow-sm' : 'hover:bg-slate-100'}`}
          >
            Flux Themes
          </button>
          <button
            type="button"
            onClick={() => setScreen('aboutdevice')}
            className={`px-3 py-1.5 rounded-xl transition ${screen === 'aboutdevice' ? 'bg-blue-600 text-white font-semibold shadow-sm' : 'hover:bg-slate-100'}`}
          >
            About Device
          </button>
          <button
            type="button"
            onClick={() => setScreen('appdrawer')}
            className={`px-3 py-1.5 rounded-xl transition ${screen === 'appdrawer' ? 'bg-blue-600 text-white font-semibold shadow-sm' : 'hover:bg-slate-100'}`}
          >
            App Drawer
          </button>
        </div>
      )}

      {/* 3D Mobile Container */}
      <div 
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={handleMouseLeave}
        className="perspective-1200 relative py-4 cursor-grab active:cursor-grabbing transition-transform"
        style={{ transform: `scale(${scale})` }}
      >
        {/* Outer Phone Hardware Chasis */}
        <div 
          className="relative w-[300px] sm:w-[320px] h-[630px] rounded-[48px] p-[10px] bg-gradient-to-b from-slate-200 via-slate-300 to-slate-400 shadow-2xl transition-transform duration-200 ease-out preserve-3d"
          style={{
            transform: `rotateX(${currentRotX}deg) rotateY(${currentRotY}deg) rotateZ(${baseRot.z}deg)`,
            boxShadow: `
              ${-currentRotY * 2}px ${20 + currentRotX * 2}px 50px rgba(0, 0, 0, 0.25),
              0 0 0 1px rgba(255, 255, 255, 0.4) inset,
              0 25px 40px -10px rgba(37, 99, 235, 0.2)
            `
          }}
        >
          {/* Subtle Metal Frame chamfer & highlights */}
          <div className="absolute inset-0 rounded-[48px] border-2 border-white/60 pointer-events-none"></div>

          {/* Side Hardware Buttons */}
          {/* Volume Rocker on Right/Left */}
          <div className="absolute -left-[13px] top-[140px] w-[3px] h-[75px] bg-gradient-to-b from-slate-300 via-slate-400 to-slate-300 rounded-l-sm shadow-md"></div>
          {/* Power Button on Right */}
          <div className="absolute -right-[13px] top-[170px] w-[3px] h-[48px] bg-gradient-to-b from-slate-300 via-slate-400 to-slate-300 rounded-r-sm shadow-md"></div>

          {/* Inner Black Bezel */}
          <div className="relative w-full h-full rounded-[40px] bg-black p-[3px] overflow-hidden shadow-inner flex flex-col">
            
            {/* Phone Screen Glass Display */}
            <div className="relative w-full h-full rounded-[37px] overflow-hidden bg-slate-900 text-white flex flex-col font-sans">
              
              {/* Dynamic Screen Reflections */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none z-40"></div>

              {/* Top Punch-Hole Front Camera & Speaker */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 flex items-center gap-1.5">
                <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-700/80 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-900/60"></div>
                </div>
              </div>

              {/* Common Status Bar */}
              <div className="relative z-40 px-5 pt-3 pb-1 flex items-center justify-between text-[11px] font-medium tracking-tight">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold">
                    {screen === 'homescreen' ? '2:11' : screen === 'lockscreen' ? '' : '12:18'}
                  </span>
                  {screen === 'homescreen' && (
                    <span className="text-[9px] bg-emerald-500 text-white px-1 py-[1px] rounded font-bold">
                      G
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <span className="text-[10px] font-mono opacity-90">2.00 KB/s</span>
                  <Wifi className="w-3 h-3" />
                  <span className="text-[10px] font-bold">4G</span>
                  <div className="flex items-center gap-0.5">
                    <span className="text-[10px] font-semibold">87</span>
                    <Battery className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                  </div>
                </div>
              </div>

              {/* ================= SCREEN CONTENT ================= */}

              {/* 1. HOMESCREEN (Canyon Wallpaper + ColorOS Widgets) */}
              {screen === 'homescreen' && (
                <div className="relative flex-1 flex flex-col justify-between p-4 overflow-hidden">
                  {/* Canyon Hot Air Balloon Wallpaper */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center"
                    style={{
                      backgroundImage: `url('https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=800&auto=format&fit=crop')`,
                      filter: 'brightness(0.95)'
                    }}
                  >
                    {/* Hot air balloon floating center */}
                    <div className="absolute top-[22%] left-1/2 -translate-x-1/2 w-20 h-24 bg-contain bg-no-repeat bg-center animate-bounce duration-1000">
                      <div className="w-16 h-20 mx-auto rounded-[50%_50%_45%_45%] bg-gradient-to-b from-amber-400 via-orange-500 to-red-600 shadow-lg border border-amber-300/40 relative">
                        <div className="absolute bottom-[-6px] left-1/2 -translate-x-1/2 w-3 h-2 bg-amber-900 rounded-sm"></div>
                      </div>
                    </div>
                  </div>

                  {/* Header Clock & Weather preview */}
                  <div className="relative z-10 pt-2 text-center text-white drop-shadow-md">
                    <div className="text-xs font-medium text-white/90 flex items-center justify-center gap-1.5">
                      <span>Sat, Aug 29</span>
                      <span>☁️ 34°</span>
                    </div>
                    <div className="text-5xl font-light tracking-tighter mt-1 font-display">
                      2:11
                    </div>
                  </div>

                  {/* ColorOS Liquid Frosted Widgets */}
                  <div className="relative z-10 space-y-2.5 my-auto">
                    <div className="grid grid-cols-2 gap-2">
                      {/* Weather Widget */}
                      <div className="rounded-2xl bg-slate-900/40 backdrop-blur-xl border border-white/20 p-2.5 shadow-lg flex flex-col justify-between h-[86px]">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-semibold flex items-center gap-1 text-white">
                            <MapPin className="w-2.5 h-2.5 text-red-400" /> Dhaka
                          </span>
                          <span className="text-xs">☁️</span>
                        </div>
                        <div>
                          <div className="text-xl font-bold tracking-tight text-white">34°</div>
                          <div className="text-[9px] text-white/80">Overcast 28°/34°</div>
                        </div>
                      </div>

                      {/* Storage / RAM Cleaner Widget */}
                      <div className="rounded-2xl bg-white/90 text-slate-900 backdrop-blur-xl border border-white/40 p-2.5 shadow-lg flex flex-col justify-between h-[86px]">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold tracking-tight text-slate-900">637MB</span>
                          <span className="text-[9px] text-emerald-600 font-bold">Fast</span>
                        </div>
                        {/* Progress Bar */}
                        <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden flex">
                          <div className="w-[58%] bg-blue-600"></div>
                          <div className="w-[12%] bg-amber-500"></div>
                        </div>
                        <div className="flex items-center justify-between text-[9px] text-slate-500">
                          <span>37.1GB / 64GB</span>
                          <button
                            type="button"
                            onClick={handleCleanUp}
                            className="px-2 py-0.5 rounded-full bg-slate-100 hover:bg-blue-50 text-blue-600 font-semibold text-[9px] border border-slate-300/60 flex items-center gap-0.5 transition"
                          >
                            <Sparkles className={`w-2.5 h-2.5 ${isCleaning ? 'animate-spin' : ''}`} />
                            {cleanedSuccess ? 'Done!' : 'Clean'}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Breeno Suggestions pill */}
                    <div className="text-center">
                      <span className="text-[9px] uppercase tracking-wider font-semibold text-white/80 drop-shadow">
                        Breeno Smart Suggestions
                      </span>
                    </div>

                    {/* App Row 1 */}
                    <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-medium">
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-11 h-11 rounded-2xl bg-white flex items-center justify-center shadow-md">
                          <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center font-bold text-white text-xs">G</div>
                        </div>
                        <span className="text-white drop-shadow-sm text-[10px]">Google</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-11 h-11 rounded-2xl bg-red-600 flex items-center justify-center shadow-md">
                          <div className="w-0 h-0 border-t-[5px] border-t-transparent border-l-[9px] border-l-white border-b-[5px] border-b-transparent ml-0.5"></div>
                        </div>
                        <span className="text-white drop-shadow-sm text-[10px]">YouTube</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-sky-400 to-blue-600 flex items-center justify-center shadow-md text-white font-bold text-xs">
                          🖼️
                        </div>
                        <span className="text-white drop-shadow-sm text-[10px]">Photos</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-400 to-amber-300 flex items-center justify-center shadow-md text-white">
                          ☀️
                        </div>
                        <span className="text-white drop-shadow-sm text-[10px]">Weather</span>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Search Bar & Dock */}
                  <div className="relative z-10 space-y-3 pb-1">
                    {/* Search Bar pill */}
                    <div className="w-full py-1.5 px-3 rounded-full bg-slate-900/40 backdrop-blur-xl border border-white/20 text-white/80 text-[11px] flex items-center justify-center gap-1.5 shadow-sm">
                      <Search className="w-3 h-3 text-white/60" />
                      <span>Search</span>
                    </div>

                    {/* ColorOS Dock */}
                    <div className="p-2 rounded-3xl bg-white/20 backdrop-blur-2xl border border-white/30 grid grid-cols-4 gap-2 shadow-xl">
                      <div className="w-11 h-11 mx-auto rounded-2xl bg-emerald-500 flex items-center justify-center shadow-md">
                        <Phone className="w-5 h-5 text-white" />
                      </div>
                      <div className="w-11 h-11 mx-auto rounded-2xl bg-emerald-600 flex items-center justify-center shadow-md text-white text-xs font-bold">
                        💬
                      </div>
                      <div className="relative w-11 h-11 mx-auto rounded-2xl bg-emerald-400 flex items-center justify-center shadow-md">
                        <MessageSquare className="w-5 h-5 text-white" />
                        <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-600 text-white text-[9px] font-bold flex items-center justify-center shadow">
                          3
                        </span>
                      </div>
                      <div className="w-11 h-11 mx-auto rounded-2xl bg-slate-800 flex items-center justify-center shadow-md">
                        <Camera className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. LOCKSCREEN (Grand Canyon, Large 02:11 Typography, Flashlight) */}
              {screen === 'lockscreen' && (
                <div className="relative flex-1 flex flex-col justify-between p-4 overflow-hidden">
                  {/* High Quality Canyon Wallpaper */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center"
                    style={{
                      backgroundImage: `url('https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=800&auto=format&fit=crop')`,
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/40"></div>
                  </div>

                  {/* Top Lock Icon & Carrier */}
                  <div className="relative z-10 pt-2 flex flex-col items-center">
                    <div className="text-[10px] text-white/90 font-medium">Grameenphone</div>
                    <div className="mt-2 w-5 h-5 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/40">
                      <span className="text-[9px]">🔒</span>
                    </div>
                  </div>

                  {/* Lockscreen Big Clock */}
                  <div className="relative z-10 my-auto text-center text-white">
                    <div className="text-xs font-medium text-white/90">Sat, Aug 29 • ☁️ 33°</div>
                    <div className="text-7xl font-bold tracking-tight font-display drop-shadow-lg leading-none mt-2">
                      02
                    </div>
                    <div className="text-7xl font-bold tracking-tight font-display drop-shadow-lg leading-none">
                      11
                    </div>

                    {/* Interactive Telegram Notification Card */}
                    {activeNotification && (
                      <div className="mt-6 mx-auto max-w-[260px] p-3 rounded-2xl bg-white/70 text-slate-900 backdrop-blur-xl border border-white/60 shadow-xl text-left animate-in fade-in duration-300">
                        <div className="flex items-center justify-between text-[10px] text-slate-600 mb-1">
                          <span className="flex items-center gap-1 font-semibold text-blue-600">
                            ✈️ Telegram • Aurora DEVs
                          </span>
                          <span>Yesterday</span>
                        </div>
                        <div className="text-xs font-bold text-slate-900">KILLER SEVEN</div>
                        <div className="text-[11px] text-slate-700 mt-0.5">Let&apos;s see what he say...</div>
                        <div className="mt-2 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setActiveNotification(false)}
                            className="px-2.5 py-1 rounded-full bg-slate-200/80 hover:bg-slate-300 text-[10px] font-semibold text-slate-800 transition"
                          >
                            Mark as read
                          </button>
                          <button
                            type="button"
                            onClick={() => setScreen('homescreen')}
                            className="px-2.5 py-1 rounded-full bg-blue-600 text-white text-[10px] font-semibold shadow-sm transition"
                          >
                            Reply
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Bottom Flashlight & Camera Icons */}
                  <div className="relative z-10 flex items-center justify-between pb-4 px-2">
                    <button 
                      type="button"
                      onClick={() => setFlashlightEnabled(!flashlightEnabled)}
                      className={`w-11 h-11 rounded-full backdrop-blur-xl border border-white/40 flex items-center justify-center transition shadow-lg ${flashlightEnabled ? 'bg-amber-400 text-slate-900' : 'bg-black/40 text-white'}`}
                    >
                      <Flashlight className="w-5 h-5" />
                    </button>
                    <button 
                      type="button"
                      onClick={() => setScreen('homescreen')}
                      className="text-xs font-semibold text-white/90 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/30 hover:bg-white/30 transition"
                    >
                      Swipe up to unlock
                    </button>
                    <button 
                      type="button"
                      onClick={() => setScreen('homescreen')}
                      className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-xl border border-white/40 flex items-center justify-center text-white shadow-lg"
                    >
                      <Camera className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* 3. CONTROL CENTER / QUICK SETTINGS (Frosted Glass Blur) */}
              {screen === 'controlcenter' && (
                <div className="relative flex-1 flex flex-col p-4 bg-gradient-to-b from-sky-400/80 via-blue-500/70 to-slate-900/90 backdrop-blur-2xl overflow-y-auto">
                  {/* Top Bar Header */}
                  <div className="flex items-center justify-between text-white drop-shadow mb-3">
                    <div className="text-sm font-bold">
                      <span className="text-red-400">10:50</span> Fri, Sep 4
                    </div>
                    <Sliders className="w-4 h-4 opacity-80" />
                  </div>

                  {/* Primary Connection Tiles */}
                  <div className="grid grid-cols-2 gap-2 mb-3">
                    <button 
                      type="button"
                      onClick={() => setWifiEnabled(!wifiEnabled)}
                      className={`p-2.5 rounded-2xl flex items-center gap-2.5 transition text-left backdrop-blur-md border ${wifiEnabled ? 'bg-blue-600 border-blue-400/60 text-white' : 'bg-white/20 border-white/20 text-white/60'}`}
                    >
                      <Wifi className="w-5 h-5" />
                      <div>
                        <div className="text-xs font-bold">Hriday</div>
                        <div className="text-[9px] opacity-80">{wifiEnabled ? 'Connected' : 'Off'}</div>
                      </div>
                    </button>

                    <button 
                      type="button"
                      onClick={() => setBluetoothEnabled(!bluetoothEnabled)}
                      className={`p-2.5 rounded-2xl flex items-center gap-2.5 transition text-left backdrop-blur-md border ${bluetoothEnabled ? 'bg-blue-600 border-blue-400/60 text-white' : 'bg-white/20 border-white/20 text-white/60'}`}
                    >
                      <Bluetooth className="w-5 h-5" />
                      <div>
                        <div className="text-xs font-bold">Bluetooth</div>
                        <div className="text-[9px] opacity-80">{bluetoothEnabled ? 'Active' : 'Off'}</div>
                      </div>
                    </button>
                  </div>

                  {/* Sliders: Brightness & Volume */}
                  <div className="grid grid-cols-2 gap-2 mb-3">
                    {/* Brightness Slider */}
                    <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-xl border border-white/30 flex flex-col justify-between h-[100px]">
                      <div className="flex items-center justify-between text-xs text-amber-300 font-semibold">
                        <Sun className="w-4 h-4" />
                        <span>{brightness}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="10" 
                        max="100" 
                        value={brightness} 
                        onChange={(e) => setBrightness(Number(e.target.value))}
                        className="w-full accent-amber-400 cursor-pointer h-1.5 rounded-lg bg-white/30"
                      />
                      <span className="text-[9px] text-white/80">Brightness</span>
                    </div>

                    {/* Volume Slider */}
                    <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-xl border border-white/30 flex flex-col justify-between h-[100px]">
                      <div className="flex items-center justify-between text-xs text-sky-200 font-semibold">
                        <Volume2 className="w-4 h-4" />
                        <span>{volume}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="100" 
                        value={volume} 
                        onChange={(e) => setVolume(Number(e.target.value))}
                        className="w-full accent-sky-400 cursor-pointer h-1.5 rounded-lg bg-white/30"
                      />
                      <span className="text-[9px] text-white/80">Media Volume</span>
                    </div>
                  </div>

                  {/* 8 Quick Toggle Round Icons */}
                  <div className="grid grid-cols-4 gap-2 mb-3 text-center">
                    <button 
                      type="button"
                      onClick={() => setFlashlightEnabled(!flashlightEnabled)}
                      className="flex flex-col items-center gap-1"
                    >
                      <div className={`w-11 h-11 rounded-full flex items-center justify-center transition border ${flashlightEnabled ? 'bg-amber-400 text-slate-900 border-amber-300' : 'bg-white/20 text-white border-white/20'}`}>
                        <Flashlight className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] text-white">Torch</span>
                    </button>

                    <button 
                      type="button"
                      onClick={() => setDndEnabled(!dndEnabled)}
                      className="flex flex-col items-center gap-1"
                    >
                      <div className={`w-11 h-11 rounded-full flex items-center justify-center transition border ${dndEnabled ? 'bg-indigo-600 text-white border-indigo-400' : 'bg-white/20 text-white border-white/20'}`}>
                        <Moon className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] text-white">DND</span>
                    </button>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center border border-blue-400">
                        <MapPin className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] text-white">Location</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-11 h-11 rounded-full bg-white/20 text-white flex items-center justify-center border border-white/20">
                        <Plane className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] text-white">Airplane</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center border border-blue-400">
                        <RotateCw className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] text-white">Auto-rotate</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center border border-blue-400">
                        <Share2 className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] text-white">OPPO Share</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-11 h-11 rounded-full bg-white/20 text-white flex items-center justify-center border border-white/20">
                        🎧
                      </div>
                      <span className="text-[9px] text-white">TWS</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-11 h-11 rounded-full bg-white/20 text-white flex items-center justify-center border border-white/20">
                        📱
                      </div>
                      <span className="text-[9px] text-white">My Device</span>
                    </div>
                  </div>

                  {/* Bottom dismiss indicator */}
                  <div className="mt-auto text-center pt-2">
                    <button
                      type="button"
                      onClick={() => setScreen('homescreen')}
                      className="w-10 h-10 rounded-full bg-white/30 backdrop-blur-md text-white font-bold text-sm mx-auto flex items-center justify-center border border-white/40 shadow-lg hover:bg-white/40"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              )}

              {/* 4. WALLPAPERS & STYLE (Flux Themes) */}
              {screen === 'wallpapers' && (
                <div className="relative flex-1 flex flex-col p-4 bg-slate-100 text-slate-900 overflow-y-auto">
                  <div className="flex items-center gap-2 mb-3">
                    <button 
                      type="button" 
                      onClick={() => setScreen('homescreen')}
                      className="text-slate-600 text-xs font-bold"
                    >
                      ←
                    </button>
                    <span className="text-sm font-bold text-slate-900">Wallpapers & style</span>
                  </div>

                  {/* Art+ Project Header */}
                  <div className="p-3 rounded-2xl bg-white border border-slate-200/80 shadow-sm mb-3">
                    <div className="text-sm font-extrabold text-slate-900 font-display">
                      Art+ <span className="text-xs text-blue-600 font-normal uppercase">Project</span>
                    </div>
                    <div className="text-xs font-bold text-slate-800 mt-1">Flux themes</div>
                    <div className="text-[10px] text-slate-500">Design your personalized style</div>

                    {/* Preview Cards */}
                    <div className="mt-3 flex items-center gap-2 overflow-x-auto pb-1">
                      <div className="w-24 h-36 rounded-xl bg-slate-800 text-white relative overflow-hidden flex-shrink-0 border-2 border-blue-600 shadow-md">
                        <img 
                          src="https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=400&auto=format&fit=crop" 
                          alt="Theme 1" 
                          className="w-full h-full object-cover" 
                        />
                        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full">
                          In use
                        </span>
                      </div>
                      <div className="w-24 h-36 rounded-xl bg-slate-800 text-white relative overflow-hidden flex-shrink-0 border border-slate-200">
                        <img 
                          src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=400&auto=format&fit=crop" 
                          alt="Theme 2" 
                          className="w-full h-full object-cover" 
                        />
                      </div>
                    </div>
                  </div>

                  {/* Always on display widget */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2.5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
                      <div className="w-full h-20 rounded-xl bg-slate-900 flex flex-col items-center justify-center text-white">
                        <span className="text-lg font-bold text-red-500 font-display">12:30</span>
                        <span className="text-[9px] text-slate-400">Sat, Aug 29</span>
                      </div>
                      <div className="text-[10px] font-bold text-slate-800 mt-1.5">Always-On Display</div>
                    </div>

                    <div className="p-2.5 rounded-2xl bg-white border border-slate-200/80 shadow-sm">
                      <div className="w-full h-20 rounded-xl bg-gradient-to-tr from-blue-500 via-indigo-600 to-rose-500 flex items-center justify-center text-white font-bold text-xs">
                        ColorOS 15
                      </div>
                      <div className="text-[10px] font-bold text-slate-800 mt-1.5">Accent Colors</div>
                    </div>
                  </div>
                </div>
              )}

              {/* 5. ABOUT DEVICE (ColorOS 15.0 on Snapdragon 665 / Ginkgo) */}
              {screen === 'aboutdevice' && (
                <div className="relative flex-1 flex flex-col p-4 bg-slate-50 text-slate-900 overflow-y-auto">
                  <div className="flex items-center gap-2 mb-3">
                    <button 
                      type="button" 
                      onClick={() => setScreen('homescreen')}
                      className="text-slate-600 text-xs font-bold"
                    >
                      ←
                    </button>
                    <span className="text-sm font-bold text-slate-900">About device</span>
                  </div>

                  {/* ColorOS 15 Banner Card */}
                  <div className="relative rounded-2xl overflow-hidden p-3 text-white shadow-md bg-gradient-to-tr from-amber-600 via-orange-500 to-purple-800 mb-3">
                    <div className="text-[9px] opacity-80">Presented by @isaec_newton</div>
                    <div className="text-xl font-black mt-1 font-display">Redmi Note 8</div>
                    <div className="text-xs font-semibold text-amber-200 mt-0.5 flex items-center gap-1">
                      ColorOS 15.0 <span className="text-[9px]">➔</span>
                    </div>
                    <div className="text-[9px] text-white/80 mt-2">Aurora DEVs Official Stable Port</div>
                  </div>

                  {/* Device Name & Storage */}
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div className="p-2.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
                      <div className="text-[10px] text-slate-400 font-medium">Device name</div>
                      <div className="text-xs font-bold text-slate-900 mt-1">Redmi Note 8</div>
                      <div className="text-[9px] text-blue-600 font-semibold mt-1">Ginkgo</div>
                    </div>

                    <div className="p-2.5 rounded-2xl bg-white border border-slate-200 shadow-sm">
                      <div className="text-[10px] text-slate-400 font-medium">Storage</div>
                      <div className="text-xs font-bold text-slate-900 mt-1">47.7 GB / 64.0 GB</div>
                      {/* Multi-color Storage Bar */}
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden flex mt-1.5">
                        <div className="w-[45%] bg-blue-600"></div>
                        <div className="w-[20%] bg-purple-500"></div>
                        <div className="w-[10%] bg-amber-400"></div>
                      </div>
                    </div>
                  </div>

                  {/* Processor & System Specs */}
                  <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-[10px] text-slate-400">Processor</div>
                        <div className="text-xs font-bold text-slate-900">Qualcomm® Snapdragon™ 665</div>
                      </div>
                      <span className="text-xs text-slate-400">➔</span>
                    </div>
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Android Version</span>
                      <span className="font-semibold text-slate-900">14 (Vanilla Ice Cream)</span>
                    </div>
                    <div className="pt-1 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Security Patch</span>
                      <span className="font-semibold text-emerald-600">September 2026</span>
                    </div>
                    <div className="pt-1 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">Kernel Version</span>
                      <span className="font-mono text-[10px] text-slate-800">4.14.342-Aurora+</span>
                    </div>
                  </div>
                </div>
              )}

              {/* 6. APP DRAWER (Search + Icons Grid) */}
              {screen === 'appdrawer' && (
                <div className="relative flex-1 flex flex-col p-4 bg-slate-900/90 text-white backdrop-blur-2xl overflow-y-auto">
                  {/* Search Bar */}
                  <div className="p-2 rounded-xl bg-white/10 border border-white/20 text-xs flex items-center gap-2 mb-3">
                    <Search className="w-3.5 h-3.5 text-white/50" />
                    <span className="text-white/60 text-[11px]">Search for an app...</span>
                  </div>

                  <div className="text-[10px] uppercase font-bold text-white/60 mb-2">App suggestions</div>
                  <div className="grid grid-cols-4 gap-2 mb-4 text-center">
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center font-bold text-xs">YT</div>
                      <span className="text-[9px]">YouTube</span>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center text-xs">WA</div>
                      <span className="text-[9px]">WhatsApp</span>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center text-xs">TG</div>
                      <span className="text-[9px]">Telegram</span>
                    </div>
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-10 h-10 rounded-xl bg-white text-blue-600 font-bold flex items-center justify-center text-xs">G</div>
                      <span className="text-[9px]">Google</span>
                    </div>
                  </div>

                  <div className="text-[10px] uppercase font-bold text-white/60 mb-2">All apps</div>
                  <div className="grid grid-cols-4 gap-2.5 text-center">
                    {['Calculator', 'Camera', 'ChatGPT', 'Claude', 'Clock', 'Discord', 'Photos', 'Weather'].map((appName, i) => (
                      <div key={appName} className="flex flex-col items-center gap-1">
                        <div className="w-10 h-10 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center text-xs">
                          {i % 2 === 0 ? '⚡' : '🚀'}
                        </div>
                        <span className="text-[9px] truncate max-w-[50px]">{appName}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-auto text-center pt-3">
                    <button
                      type="button"
                      onClick={() => setScreen('homescreen')}
                      className="text-xs text-blue-400 font-semibold hover:underline"
                    >
                      ← Back to Home
                    </button>
                  </div>
                </div>
              )}

              {/* Bottom Gesture Bar */}
              <div className="relative z-50 w-full py-1.5 flex justify-center bg-transparent">
                <div 
                  onClick={() => setScreen('homescreen')}
                  className="w-24 h-1 rounded-full bg-white/60 hover:bg-white cursor-pointer transition"
                ></div>
              </div>

            </div>
          </div>
        </div>

        {/* 3D Angle Preset Switchers below phone */}
        {interactiveControls && (
          <div className="mt-4 flex items-center justify-center gap-2">
            <span className="text-[11px] font-medium text-slate-400 mr-1">3D Angle:</span>
            <button
              type="button"
              onClick={() => setTiltMode('flat')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${tiltMode === 'flat' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              Flat
            </button>
            <button
              type="button"
              onClick={() => setTiltMode('left')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${tiltMode === 'left' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              Left 3D
            </button>
            <button
              type="button"
              onClick={() => setTiltMode('right')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${tiltMode === 'right' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              Right 3D
            </button>
            <button
              type="button"
              onClick={() => setTiltMode('hero')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${tiltMode === 'hero' ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              Hero Tilt
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
