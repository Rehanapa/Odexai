import React from 'react';
import { DeviceInfo } from '../types';
import { BookOpen, AlertTriangle } from 'lucide-react';

interface FlashingGuideModalProps {
  device: DeviceInfo | null;
  onClose: () => void;
}

export const FlashingGuideModal: React.FC<FlashingGuideModalProps> = ({ device, onClose }) => {
  if (!device) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#121318] p-6 sm:p-8 shadow-2xl border border-[#262838] text-white max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-[#21232e] mb-6">
          <div>
            <div className="inline-flex items-center gap-1 text-xs font-bold text-blue-400 uppercase tracking-wider mb-1 font-mono">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Installation Guide</span>
            </div>
            <h3 className="text-2xl font-bold text-white font-display">
              How to Flash on {device.name} [{device.codename}]
            </h3>
            <p className="text-xs text-neutral-400">Official step-by-step instructions for a clean and error-free installation</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-[#1d1f2b] text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Warning Banner */}
        <div className="mb-6 p-4 rounded-2xl bg-[#231d16] border border-[#45331f] text-[#fcd34d] text-xs flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Backup Required:</span> Clean flashing will wipe your internal storage. Make sure to back up all your photos, chats, and essential files to a PC or cloud before proceeding.
          </div>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="space-y-4 text-xs text-neutral-300">
          
          {/* Step 1 */}
          <div className="p-4 rounded-2xl bg-[#161720] border border-[#272938]">
            <div className="flex items-center gap-2 font-bold text-white text-sm mb-1.5">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">1</span>
              <span>Prerequisites</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-neutral-400 ml-2">
              <li>Unlocked Bootloader on your {device.name}</li>
              <li>OrangeFox or TWRP Recovery installed</li>
              <li>Battery charged to at least 50%</li>
              <li>Aurora ColorOS 15 zip file downloaded on your SD Card or USB OTG</li>
            </ul>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-2xl bg-[#161720] border border-[#272938]">
            <div className="flex items-center gap-2 font-bold text-white text-sm mb-1.5">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">2</span>
              <span>Wipe Partitions (Clean Flash)</span>
            </div>
            <p className="text-neutral-400 mb-2">Reboot to OrangeFox/TWRP recovery by holding <kbd className="px-1.5 py-0.5 rounded bg-[#202230] border border-[#303244] text-neutral-200 font-mono text-[11px]">Power + Volume Up</kbd>.</p>
            <div className="p-2.5 rounded-xl bg-[#0c0d10] text-neutral-200 font-mono text-[11px] space-y-1 border border-[#222430]">
              <div>Go to &gt; Wipe &gt; Advanced Wipe</div>
              <div>Select: Dalvik / ART Cache, Cache, System, Vendor, Data</div>
              <div>Swipe to Wipe</div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-2xl bg-[#161720] border border-[#272938]">
            <div className="flex items-center gap-2 font-bold text-white text-sm mb-1.5">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">3</span>
              <span>Flash Aurora ROM</span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#0c0d10] text-neutral-200 font-mono text-[11px] space-y-1 border border-[#222430]">
              <div>Go to &gt; Install &gt; Select Aurora-ColorOS-{device.codename}.zip</div>
              <div>Swipe to Flash (Wait 3-5 minutes for completion)</div>
            </div>
          </div>

          {/* Step 4 */}
          <div className="p-4 rounded-2xl bg-[#161720] border border-[#272938]">
            <div className="flex items-center gap-2 font-bold text-white text-sm mb-1.5">
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">4</span>
              <span>Format Data & Reboot</span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#0c0d10] text-neutral-200 font-mono text-[11px] space-y-1 border border-[#222430]">
              <div>Go to &gt; Wipe &gt; Format Data &gt; Type &apos;yes&apos; &gt; Confirm</div>
              <div>Reboot System</div>
            </div>
            <p className="mt-2 text-neutral-400">First boot takes about 3 to 7 minutes. Do not panic if it shows the ColorOS bootanimation for a few minutes.</p>
          </div>

        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-[#21232e] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 transition cursor-pointer"
          >
            Got It, Thanks!
          </button>
        </div>

      </div>
    </div>
  );
};
