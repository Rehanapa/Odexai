import React, { useState, useEffect } from 'react';
import { Send, Shield, Menu, X, Smartphone, Sparkles } from 'lucide-react';
import { Logo } from './Logo';
import { TELEGRAM_CHANNELS } from '../data/defaultData';

interface NavbarProps {
  onOpenAdmin: () => void;
  telegramLink?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenAdmin, 
  telegramLink = TELEGRAM_CHANNELS.updates 
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
      const winScroll = document.documentElement.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = height > 0 ? (winScroll / height) * 100 : 0;
      setScrollProgress(scrolled);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Overview', href: '#overview' },
    { name: 'Screenshots Gallery', href: '#gallery' },
    { name: 'Supported Devices', href: '#devices' },
    { name: 'Features', href: '#features' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Community', href: '#community' },
  ];

  return (
    <>
      {/* Scroll Progress Bar at the very top (Solid blue, no gradients) */}
      <div className="fixed top-0 left-0 right-0 h-[3px] bg-transparent z-50 pointer-events-none">
        <div
          className="h-full bg-blue-600 transition-all duration-75"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <header 
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled 
            ? 'py-2.5 bg-[#0e0f13]/90 backdrop-blur-xl border-b border-[#1f2026] shadow-xl' 
            : 'py-4 bg-[#0e0f13]/60 backdrop-blur-md border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Brand Logo */}
          <a href="#overview" className="flex items-center gap-2 group">
            <Logo size="md" />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 p-1 rounded-full bg-[#16171e] border border-[#262732] text-xs font-semibold text-neutral-300">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-3.5 py-1.5 rounded-full hover:text-white hover:bg-[#20222b] transition-all"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action Buttons */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* Admin Portal Button */}
            <button
              type="button"
              onClick={onOpenAdmin}
              title="Admin Portal"
              className="p-2 rounded-xl text-neutral-300 hover:text-white bg-[#16171e] hover:bg-[#20222b] border border-[#262732] transition flex items-center gap-1.5 text-xs font-medium cursor-pointer"
            >
              <Shield className="w-4 h-4 text-blue-500" />
              <span className="hidden lg:inline">Admin</span>
            </button>

            {/* Telegram Channel CTA (Solid blue, no gradient) */}
            <a
              href={telegramLink}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md transition-all flex items-center gap-2 group active:scale-95 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-transform" />
              <span>Join Telegram</span>
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              type="button"
              onClick={onOpenAdmin}
              title="Admin Portal"
              className="p-2 rounded-lg text-neutral-300 bg-[#16171e] border border-[#262732]"
            >
              <Shield className="w-4 h-4 text-blue-500" />
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-[#16171e] text-white border border-[#262732] focus:outline-none cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Menu Drawer */}
        {mobileMenuOpen && (
          <div className="sm:hidden px-4 pt-3 pb-6 bg-[#121318] border-b border-[#23242e] shadow-2xl space-y-3">
            <div className="flex flex-col space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 rounded-xl text-sm font-semibold text-neutral-200 hover:bg-[#1c1d25] hover:text-white transition"
                >
                  {link.name}
                </a>
              ))}
            </div>

            <div className="pt-2 border-t border-[#1e1f28] flex flex-col gap-2">
              <a
                href={telegramLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>Join Official Telegram Channel</span>
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
