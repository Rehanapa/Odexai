import { RomRelease, DeviceInfo, RomReview, TeamMember, ScreenshotGalleryItem } from '../types';

export const INITIAL_ROMS: RomRelease[] = [
  {
    id: 'aurora-ginkgo-15',
    name: 'Aurora ColorOS 15.0 Ginkgo Edition',
    codename: 'Ginkgo',
    deviceModel: 'Redmi Note 8 / 8T',
    chipset: 'Qualcomm Snapdragon 665 (sm6125)',
    androidVersion: 'Android 14 / ColorOS 15',
    colorOsVersion: 'v15.0.2 Stable',
    status: 'Official',
    releaseDate: '2026-09-08',
    fileSize: '2.84 GB',
    downloadTelegramUrl: 'https://t.me/Aurora_update',
    supportGroupUrl: 'https://t.me/Avroradevs',
    description: 'The Ginkgo ROM offers enhanced performance, stability, and user-friendly features tailored for optimal experience on the Redmi Note 8/8T.',
    changelog: [
      'Ported latest ColorOS 15.0.2 with fluid liquid-glass animation engine',
      'Kernel upstreamed to 4.14.342 with dynamic CPU boost for smooth 60fps',
      'Camera2API enabled with full support for GCam & stock Leica color profiles',
      'Enabled Dolby Atmos audio processing with quad-speaker virtual surround',
      'Fixed VoLTE / VoWiFi network registration on all major carriers',
      'Optimized thermal throttling curve: remains cool under heavy multitasking',
      'SafetyNet and Play Integrity pass out-of-the-box (Banking apps ready)',
      'Custom Flux Themes & Always-On Display styles unlocked'
    ],
    bannerGradient: 'bg-blue-600',
    accentColor: '#2563EB',
    maintainer: '@isaec_newton'
  },
  {
    id: 'aurora-stone-15',
    name: 'Aurora ColorOS 15.0 Stone Ultra',
    codename: 'Stone',
    deviceModel: 'Redmi Note 12 5G',
    chipset: 'Qualcomm Snapdragon 4 Gen 1 (SM4375)',
    androidVersion: 'Android 14 / ColorOS 15',
    colorOsVersion: 'v15.0.1 Stable',
    status: 'Official',
    releaseDate: '2026-09-11',
    fileSize: '3.12 GB',
    downloadTelegramUrl: 'https://t.me/Aurora_update',
    supportGroupUrl: 'https://t.me/Avroradevs',
    description: 'The Stone ROM is designed to unlock the full potential of the Redmi Note 12 5G, with the latest updates and improvements.',
    changelog: [
      'Unlocked true 120Hz refresh rate across all ColorOS UI elements & apps',
      'Full 5G Dual SIM standalone carrier aggregation support',
      'SuperVOOC 33W fast-charging algorithms port for optimal battery health',
      'Breeno AI smart suggestions and liquid blur notification shade',
      'Zero bloatware: debloated over 85 unused system packages for ultra-light RAM footprint',
      'Custom touch polling rate increased to 240Hz for hyper-responsive gaming'
    ],
    bannerGradient: 'bg-red-600',
    accentColor: '#DC2626',
    maintainer: '@isaec_newton'
  },
  {
    id: 'aurora-lavender-15',
    name: 'Aurora ColorOS 15.0 Lavender Reborn',
    codename: 'Lavender',
    deviceModel: 'Redmi Note 7 / 7S',
    chipset: 'Qualcomm Snapdragon 660 AIE',
    androidVersion: 'Android 14 / ColorOS 15',
    colorOsVersion: 'v15.0.0 Special Edition',
    status: 'Stable',
    releaseDate: '2026-09-04',
    fileSize: '2.68 GB',
    downloadTelegramUrl: 'https://t.me/Aurora_update',
    supportGroupUrl: 'https://t.me/Avroradevs',
    description: 'Breathe new life into the legendary Redmi Note 7/7S with an optimized, lightweight ColorOS 15 port with zero lag and great battery life.',
    changelog: [
      'Engineered specifically for Snapdragon 660 architecture with Low-RAM flags',
      'Ultra-smooth animations tuned at solid 60FPS lock',
      'Overnight idle battery drain reduced to under 1.2%',
      'Stock 48MP GM1 sensor fully functional with 4K recording',
      'Integrated Dirac HD sound processing profiles'
    ],
    bannerGradient: 'bg-emerald-600',
    accentColor: '#059669',
    maintainer: '@im_nagasaki'
  }
];

export const COLOROS_SCREENSHOTS: ScreenshotGalleryItem[] = [
  {
    id: 'screen-lock',
    title: 'ColorOS 15 Lock Screen',
    category: 'Lock Screen',
    image: '/screenshots/Screenshot_2026-08-29-14-11-17-52.jpg',
    description: 'Cinematic depth clock (02:11) with Grand Canyon balloon wallpaper, carrier connectivity, camera and flashlight quick triggers.',
    highlights: ['Depth Clock Effect', 'Dynamic Glance Notification', 'Sub-second Unlock Speed'],
    tag: 'Depth Clock',
    tagColor: 'blue'
  },
  {
    id: 'screen-home',
    title: 'Fluid Home Screen',
    category: 'System UI',
    image: '/screenshots/Screenshot_2026-08-29-14-11-49-10_b783bf344239542886fee7b48fa4b892.jpg',
    description: 'Clean Home screen featuring real-time Dhaka 34° weather widget, one-tap RAM cleaner (637MB), Breeno suggestions, and iconic app dock.',
    highlights: ['Instant Storage Cleaner', 'Breeno Smart Suggestions', '60 FPS Desktop Transition'],
    tag: 'Breeno Launcher',
    tagColor: 'green'
  },
  {
    id: 'screen-control',
    title: 'Frosted Control Center',
    category: 'Control Center',
    image: '/screenshots/Screenshot_2026-09-05-00-18-09-73_b783bf344239542886fee7b48fa4b892.jpg',
    description: 'Redesigned Quick Settings with fluid frosted blur, split network & audio sliders, TWS Bluetooth indicator, and responsive tile animations.',
    highlights: ['Tactile Volume & Brightness Sliders', 'Real-time TWS Status', 'Liquid Glass Backdrop'],
    tag: 'Control Center',
    tagColor: 'blue'
  },
  {
    id: 'screen-control-exp',
    title: 'Expanded Quick Settings',
    category: 'Control Center',
    image: '/screenshots/Screenshot_2026-09-05-00-19-30-52_b783bf344239542886fee7b48fa4b892.jpg',
    description: 'Full toggle panel offering instant access to Dark Mode, Eye Comfort, Screen Recorder, OPPO Share, and dynamic NFC control.',
    highlights: ['Full 16-Tile Grid', 'Haptic Tile Feedback', 'Customizable Quick Actions'],
    tag: 'Expanded Hub',
    tagColor: 'red'
  },
  {
    id: 'screen-drawer',
    title: 'Fast App Drawer',
    category: 'System UI',
    image: '/screenshots/Screenshot_2026-09-04-22-50-36-43_b783bf344239542886fee7b48fa4b892.jpg',
    description: 'Smooth scrolling app drawer with smart app suggestions, rapid alphabet scrubber, and lightning search indexing.',
    highlights: ['Alphabet Fast Scrubber', 'Zero Frame Drop', 'Predictive App Suggestions'],
    tag: 'App Drawer',
    tagColor: 'brown'
  },
  {
    id: 'screen-about',
    title: 'About Device & Specifications',
    category: 'Settings',
    image: '/screenshots/Screenshot_2026-09-05-00-18-28-91_fc704e6b13c4fb26bf5e411f75da84f2.jpg',
    description: 'Official ColorOS 15 certification page displaying Snapdragon 665 octa-core CPU, RAM expansion, storage breakdown, and official build tags.',
    highlights: ['Snapdragon 665 Tuning', 'RAM Expansion Support', 'Official Security Level'],
    tag: 'About Phone',
    tagColor: 'blue'
  },
  {
    id: 'screen-themes',
    title: 'Flux Theme & Personalization',
    category: 'Personalization',
    image: '/screenshots/Screenshot_2026-09-05-00-18-04-63_b783bf344239542886fee7b48fa4b892.jpg',
    description: 'Extensive styling studio to customize lockscreen typography, Always-On Display styles, ambient wallpapers, and system icon shapes.',
    highlights: ['Dynamic Wallpaper Depth', 'AOD Always-On Display', 'Custom Icon Shape Engine'],
    tag: 'Flux Themes',
    tagColor: 'red'
  },
  {
    id: 'screen-features',
    title: 'Special Features & Fluid Engine',
    category: 'Settings',
    image: '/screenshots/Screenshot_2026-09-05-00-19-06-23_e36a787ecbdd931f753253df745e8a64.jpg',
    description: 'ColorOS 15 Special Features panel featuring Flexible Windows, Smart Sidebar, Kid Space, Simple Mode, and system-wide fluid motion physics.',
    highlights: ['Smart Sidebar', 'Flexible Window Multitasking', 'Fluid Motion Physics'],
    tag: 'Special Features',
    tagColor: 'green'
  }
];

export const SUPPORTED_DEVICES: DeviceInfo[] = [
  {
    id: 'ginkgo',
    codename: 'Ginkgo',
    name: 'Redmi Note 8 / 8T',
    chipset: 'Qualcomm Snapdragon 665',
    camera: '48MP Quad AI Camera',
    display: '6.3" FHD+ Dot Drop Display',
    battery: '4000mAh with 18W Fast Charge',
    description: 'The Ginkgo ROM offers enhanced performance, stability, and user-friendly features tailored for optimal experience on the Redmi Note 8/8T.',
    romCount: 6,
    highlightTag: 'Most Popular',
    accentTheme: 'blue',
    deviceColorName: 'Neptune Blue / Moonlight White'
  },
  {
    id: 'stone',
    codename: 'Stone',
    name: 'Redmi Note 12 5G',
    chipset: 'Qualcomm Snapdragon 4 Gen 1',
    camera: '48MP Triple AI Camera',
    display: '6.67" Super AMOLED 120Hz',
    battery: '5000mAh with 33W Fast Charge',
    description: 'The Stone ROM is designed to unlock the full potential of the Redmi Note 12 5G, with the latest updates and improvements.',
    romCount: 4,
    highlightTag: '120Hz 5G Ready',
    accentTheme: 'cyan',
    deviceColorName: 'Frosted Green / Matte Ice Blue'
  },
  {
    id: 'lavender',
    codename: 'Lavender',
    name: 'Redmi Note 7S',
    chipset: 'Qualcomm Snapdragon 660 AIE',
    camera: '48MP Dual Rear Camera',
    display: '6.3" FHD+ LTPS Display',
    battery: '4000mAh with Quick Charge 4.0',
    description: 'The Lavender ROM ensures smooth functionality and added customizations, making it an excellent choice for Redmi Note 7S users.',
    romCount: 5,
    highlightTag: 'Long Battery Life',
    accentTheme: 'red',
    deviceColorName: 'Onyx Black / Ruby Red'
  }
];

export const INITIAL_REVIEWS: RomReview[] = [
  {
    id: 'rev-1',
    author: 'Tanvir Hossain',
    telegramHandle: '@tanvir_geek',
    deviceName: 'Redmi Note 8',
    deviceCodename: 'Ginkgo',
    romVersion: 'ColorOS 15.0.2',
    rating: 5,
    title: 'Literally butter smooth! Zero frame drops',
    comment: 'Flashing this made my old Note 8 feel like a 2026 flagship phone! The control center frosted blur is gorgeous, RAM management with 8+ apps open is phenomenal, and battery standby lost only 2% overnight. Huge respect to @isaec_newton!',
    batteryLifeRating: 5,
    smoothnessRating: 5,
    gamingRating: 4,
    date: '2026-09-12',
    verified: true,
    upvotes: 42
  },
  {
    id: 'rev-2',
    author: 'Dev Sharma',
    telegramHandle: '@dev_modder',
    deviceName: 'Redmi Note 12 5G',
    deviceCodename: 'Stone',
    romVersion: 'ColorOS 15.0.1',
    rating: 5,
    title: '120Hz is finally buttery without stutters',
    comment: 'Stock MIUI/HyperOS was always dropping to 60Hz in random apps. On Aurora ColorOS 15, 120Hz stays locked everywhere! Banking apps pass Play Integrity without root modules, and SuperVOOC 33W charges blazing fast.',
    batteryLifeRating: 5,
    smoothnessRating: 5,
    gamingRating: 5,
    date: '2026-09-10',
    verified: true,
    upvotes: 31
  },
  {
    id: 'rev-3',
    author: 'Farhan Kurohane',
    telegramHandle: '@farhan_note7',
    deviceName: 'Redmi Note 7S',
    deviceCodename: 'Lavender',
    romVersion: 'ColorOS 15.0.0',
    rating: 5,
    title: 'Revived my 7-year old phone completely',
    comment: 'I was about to sell my Note 7S until I tried this ROM by @im_nagasaki. Snapdragon 660 handles ColorOS 15 surprisingly well with the custom LZ4 ZRAM profile. Audio quality via 3.5mm jack with Dolby is crystal clear!',
    batteryLifeRating: 4,
    smoothnessRating: 5,
    gamingRating: 4,
    date: '2026-09-07',
    verified: true,
    upvotes: 27
  },
  {
    id: 'rev-4',
    author: 'Alexandru M.',
    telegramHandle: '@alex_roms',
    deviceName: 'Redmi Note 8T',
    deviceCodename: 'Ginkgo',
    romVersion: 'ColorOS 15.0.2',
    rating: 5,
    title: 'NFC works flawlessly on Note 8T!',
    comment: 'Google Pay contactless payment works instantly without any extra Magisk modules. Very clean build, zero bloat, beautiful hot air balloon wallpaper and widgets look aesthetic.',
    batteryLifeRating: 5,
    smoothnessRating: 5,
    gamingRating: 4,
    date: '2026-09-09',
    verified: true,
    upvotes: 19
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    name: 'Isaac Newton',
    role: 'Project OWNER + Lead Developer',
    handle: '@isaec_newton',
    telegramUrl: 'https://t.me/isaec_newton',
    avatarText: 'IN',
    accent: 'red',
    tagline: 'Kernel Hacker, ColorOS Porter & Firmware Architect'
  },
  {
    name: 'Mr Kurohane',
    role: 'Moderator & Core Developer',
    handle: '@im_nagasaki',
    telegramUrl: 'https://t.me/im_nagasaki',
    avatarText: 'KN',
    accent: 'blue',
    tagline: 'System Tuning, Vendor Trees & Lavender Maintainer'
  },
  {
    name: 'Abdur Rahman',
    role: 'Website Designer & Builder',
    handle: '@MATRIX',
    telegramUrl: 'https://t.me/Aurora_update',
    avatarText: 'AR',
    accent: 'blue',
    tagline: 'UI/UX Crafting, Liquid Glass Concept & Web Architect'
  }
];

export const TELEGRAM_CHANNELS = {
  updates: 'https://t.me/Aurora_update',
  support: 'https://t.me/Avroradevs',
  updatesHandle: '@Aurora_update',
  supportHandle: '@Avroradevs'
};
