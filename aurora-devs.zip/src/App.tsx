import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { RomGallery } from './components/RomGallery';
import { DeviceShowcase } from './components/DeviceShowcase';
import { FeaturesSection } from './components/FeaturesSection';
import { ReviewsSection } from './components/ReviewsSection';
import { TelegramCommunity } from './components/TelegramCommunity';
import { Footer } from './components/Footer';
import { AdminPanel } from './components/AdminPanel';
import { ChangelogModal } from './components/ChangelogModal';
import { FlashingGuideModal } from './components/FlashingGuideModal';
import { ScreenshotLightbox } from './components/ScreenshotLightbox';
import { 
  INITIAL_ROMS, 
  SUPPORTED_DEVICES, 
  INITIAL_REVIEWS, 
  TELEGRAM_CHANNELS,
  COLOROS_SCREENSHOTS
} from './data/defaultData';
import { RomRelease, DeviceInfo, RomReview, ScreenshotGalleryItem } from './types';
import { Check } from 'lucide-react';

export default function App() {
  // LocalStorage Persistence for ROMs
  const [roms, setRoms] = useState<RomRelease[]>(() => {
    try {
      const saved = localStorage.getItem('aurora_roms_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load saved ROMs', e);
    }
    return INITIAL_ROMS;
  });

  // LocalStorage Persistence for Reviews
  const [reviews, setReviews] = useState<RomReview[]>(() => {
    try {
      const saved = localStorage.getItem('aurora_reviews_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load saved reviews', e);
    }
    return INITIAL_REVIEWS;
  });

  // LocalStorage Persistence for Telegram Links
  const [telegramConfig, setTelegramConfig] = useState(() => {
    try {
      const saved = localStorage.getItem('aurora_telegram_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load telegram config', e);
    }
    return TELEGRAM_CHANNELS;
  });

  // LocalStorage Persistence for Screenshots
  const [screenshots, setScreenshots] = useState<ScreenshotGalleryItem[]>(() => {
    try {
      const saved = localStorage.getItem('aurora_screenshots_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load saved screenshots', e);
    }
    return COLOROS_SCREENSHOTS;
  });

  // Modals state
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [selectedRomForChangelog, setSelectedRomForChangelog] = useState<RomRelease | null>(null);
  const [selectedDeviceForGuide, setSelectedDeviceForGuide] = useState<DeviceInfo | null>(null);
  const [selectedScreenshot, setSelectedScreenshot] = useState<ScreenshotGalleryItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('aurora_roms_v2', JSON.stringify(roms));
    } catch (e) {
      console.error(e);
    }
  }, [roms]);

  useEffect(() => {
    try {
      localStorage.setItem('aurora_reviews_v2', JSON.stringify(reviews));
    } catch (e) {
      console.error(e);
    }
  }, [reviews]);

  useEffect(() => {
    try {
      localStorage.setItem('aurora_telegram_v2', JSON.stringify(telegramConfig));
    } catch (e) {
      console.error(e);
    }
  }, [telegramConfig]);

  useEffect(() => {
    try {
      localStorage.setItem('aurora_screenshots_v2', JSON.stringify(screenshots));
    } catch (e) {
      console.error(e);
    }
  }, [screenshots]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleScrollToDevices = () => {
    const el = document.getElementById('devices');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToGallery = () => {
    const el = document.getElementById('gallery');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenScreenshotById = (id: string) => {
    const found = screenshots.find((s) => s.id === id);
    if (found) {
      setSelectedScreenshot(found);
    }
  };

  // Lightbox Navigation
  const handleSelectNextScreenshot = (currentItem: ScreenshotGalleryItem) => {
    if (!screenshots.length) return;
    const currentIndex = screenshots.findIndex(s => s.id === currentItem.id);
    const nextIndex = currentIndex >= 0 ? (currentIndex + 1) % screenshots.length : 0;
    setSelectedScreenshot(screenshots[nextIndex]);
  };

  const handleSelectPrevScreenshot = (currentItem: ScreenshotGalleryItem) => {
    if (!screenshots.length) return;
    const currentIndex = screenshots.findIndex(s => s.id === currentItem.id);
    const prevIndex = currentIndex >= 0 ? (currentIndex - 1 + screenshots.length) % screenshots.length : 0;
    setSelectedScreenshot(screenshots[prevIndex]);
  };

  // Add Review
  const handleAddReview = (newReviewData: Omit<RomReview, 'id' | 'date' | 'upvotes' | 'verified'>) => {
    const newRev: RomReview = {
      ...newReviewData,
      id: `rev-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      verified: true,
      upvotes: 1
    };
    setReviews(prev => [newRev, ...prev]);
    showToast('Review posted successfully! Thank you for supporting Aurora DEVs.');
  };

  // Upvote Review
  const handleUpvoteReview = (id: string) => {
    setReviews(prev =>
      prev.map(r => r.id === id ? { ...r, upvotes: r.upvotes + 1 } : r)
    );
    showToast('Upvoted review!');
  };

  // Admin Updates
  const handleUpdateRoms = (updatedRoms: RomRelease[]) => {
    setRoms(updatedRoms);
    showToast('ROM catalog updated successfully');
  };

  const handleUpdateReviews = (updatedReviews: RomReview[]) => {
    setReviews(updatedReviews);
    showToast('Reviews updated');
  };

  const handleUpdateScreenshots = (updatedScreenshots: ScreenshotGalleryItem[]) => {
    setScreenshots(updatedScreenshots);
    showToast('Screenshot gallery updated');
  };

  const handleUpdateTelegramLinks = (updates: string, support: string) => {
    setTelegramConfig(prev => ({
      ...prev,
      updates,
      support
    }));
    showToast('Telegram links updated');
  };

  const handleResetToDefaults = () => {
    setRoms(INITIAL_ROMS);
    setReviews(INITIAL_REVIEWS);
    setScreenshots(COLOROS_SCREENSHOTS);
    setTelegramConfig(TELEGRAM_CHANNELS);
    localStorage.removeItem('aurora_roms_v2');
    localStorage.removeItem('aurora_reviews_v2');
    localStorage.removeItem('aurora_screenshots_v2');
    localStorage.removeItem('aurora_telegram_v2');
    showToast('Reset data to curated default state');
  };

  return (
    <div className="min-h-screen bg-[#0a0b0e] text-white font-sans selection:bg-blue-600 selection:text-white flex flex-col relative">
      {/* Main Navigation */}
      <Navbar 
        onOpenAdmin={() => setIsAdminOpen(true)} 
        telegramLink={telegramConfig.updates} 
      />

      {/* Main Landing Sections */}
      <main className="flex-1">
        {/* Hero Section: Smoothhh Like A Butter (Direct reproduction of User Reference Slide 1) */}
        <Hero 
          onScrollToDevices={handleScrollToDevices}
          onScrollToGallery={handleScrollToGallery}
          onOpenScreenshot={handleOpenScreenshotById}
          telegramLink={telegramConfig.updates} 
        />

        {/* Real Device Screenshots Gallery (Horizon Scroll & Grid Modes with Phone Hardware Frame) */}
        <RomGallery 
          screenshots={screenshots}
          onSelectScreenshot={(item) => setSelectedScreenshot(item)}
        />

        {/* Supported Devices Section matching user's slide 3 */}
        <DeviceShowcase
          roms={roms}
          devices={SUPPORTED_DEVICES}
          onOpenChangelog={(rom) => setSelectedRomForChangelog(rom)}
          onOpenFlashingGuide={(device) => setSelectedDeviceForGuide(device)}
        />

        {/* Core Features / Kernel Tweaks / Audio Engine */}
        <FeaturesSection />

        {/* Community Reviews & Interactive Submission */}
        <ReviewsSection
          reviews={reviews}
          devices={SUPPORTED_DEVICES}
          onAddReview={handleAddReview}
          onUpvoteReview={handleUpvoteReview}
        />

        {/* Telegram Community & Team Credits matching user's slide 4 */}
        <TelegramCommunity
          updatesLink={telegramConfig.updates}
          supportLink={telegramConfig.support}
        />
      </main>

      {/* Footer */}
      <Footer 
        onOpenAdmin={() => setIsAdminOpen(true)}
        telegramLink={telegramConfig.updates}
        supportLink={telegramConfig.support}
      />

      {/* Modals */}
      {/* 1. Screenshot Lightbox Frame (Full interactive inspector with keyboard navigation) */}
      <ScreenshotLightbox
        item={selectedScreenshot}
        items={screenshots}
        onClose={() => setSelectedScreenshot(null)}
        onSelect={(item) => setSelectedScreenshot(item)}
        onSelectNext={handleSelectNextScreenshot}
        onSelectPrev={handleSelectPrevScreenshot}
        onScrollToDevices={handleScrollToDevices}
      />

      {/* 2. Admin Panel */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        roms={roms}
        reviews={reviews}
        screenshots={screenshots}
        onUpdateRoms={handleUpdateRoms}
        onUpdateReviews={handleUpdateReviews}
        onUpdateScreenshots={handleUpdateScreenshots}
        onResetToDefaults={handleResetToDefaults}
        telegramLink={telegramConfig.updates}
        supportLink={telegramConfig.support}
        onUpdateTelegramLinks={handleUpdateTelegramLinks}
      />

      {/* 3. Changelog Modal */}
      <ChangelogModal
        rom={selectedRomForChangelog}
        onClose={() => setSelectedRomForChangelog(null)}
      />

      {/* 4. Flashing Guide Modal */}
      <FlashingGuideModal
        device={selectedDeviceForGuide}
        onClose={() => setSelectedDeviceForGuide(null)}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-[#161722] text-white text-xs font-semibold shadow-2xl flex items-center gap-2 border border-[#2b2d3e] animate-in fade-in slide-in-from-bottom-5 duration-300">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
