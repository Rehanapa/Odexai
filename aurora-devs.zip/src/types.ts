export type DeviceCodename = 'ginkgo' | 'stone' | 'lavender' | string;

export interface RomRelease {
  id: string;
  name: string;
  codename: string;
  deviceModel: string;
  chipset: string;
  androidVersion: string;
  colorOsVersion: string;
  status: 'Official' | 'Stable' | 'Beta';
  releaseDate: string;
  fileSize: string;
  downloadTelegramUrl: string;
  supportGroupUrl: string;
  description: string;
  changelog: string[];
  bannerGradient: string;
  accentColor: string;
  maintainer: string;
}

export interface DeviceInfo {
  id: string;
  codename: string;
  name: string;
  chipset: string;
  camera: string;
  display: string;
  battery: string;
  description: string;
  romCount: number;
  highlightTag: string;
  accentTheme: 'blue' | 'red' | 'cyan';
  deviceColorName: string;
}

export interface RomReview {
  id: string;
  author: string;
  telegramHandle?: string;
  deviceName: string;
  deviceCodename: string;
  romVersion: string;
  rating: number; // 1 - 5
  title: string;
  comment: string;
  batteryLifeRating: number; // 1 - 5
  smoothnessRating: number; // 1 - 5
  gamingRating: number; // 1 - 5
  date: string;
  verified: boolean;
  upvotes: number;
}

export interface TeamMember {
  name: string;
  role: string;
  handle: string;
  telegramUrl: string;
  avatarText: string;
  accent: 'red' | 'blue' | 'green' | 'brown';
  tagline?: string;
}

export type GalleryScreenType = 
  | 'homescreen' 
  | 'lockscreen' 
  | 'controlcenter' 
  | 'wallpapers' 
  | 'aboutdevice' 
  | 'appdrawer';

export interface ScreenshotGalleryItem {
  id: string;
  title: string;
  category: 'System UI' | 'Settings' | 'Control Center' | 'Personalization' | 'Lock Screen';
  image: string;
  description: string;
  highlights: string[];
  tag: string;
  tagColor: 'blue' | 'red' | 'green' | 'brown' | 'white';
}
